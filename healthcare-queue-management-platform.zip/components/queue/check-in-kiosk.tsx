'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { useState } from 'react'
import { QRCodeSVG } from 'qrcode.react'
import { Loader2, Printer, QrCode, TicketCheck } from 'lucide-react'
import { queue } from '@/lib/api'
import { refreshQueues, useDoctors, useHospitals } from '@/lib/hooks'
import type { Token } from '@/lib/types'
import { Card, CardHeader, Field, PageHeader, Tabs, inputClass } from '@/components/ui-kit'
import { Button, buttonVariants } from '@/components/ui/button'

type Mode = 'qr' | 'walk-in'

export function CheckInKiosk() {
  const params = useSearchParams()
  const { data: hospitals } = useHospitals()
  const { data: doctors } = useDoctors()
  const [mode, setMode] = useState<Mode>('qr')
  const [hospitalId, setHospitalId] = useState(params.get('hospital') ?? 'h1')
  const [doctorId, setDoctorId] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [token, setToken] = useState<Token | null>(null)

  const hospitalDoctors = doctors?.filter((d) => d.hospitalId === hospitalId) ?? []
  const doctor = doctors?.find((d) => d.id === (token?.doctorId ?? doctorId))
  const origin = typeof window !== 'undefined' ? window.location.origin : ''

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!doctorId) return setError('Choose a doctor')
    if (name.trim().length < 2) return setError('Enter your name')
    if (phone && !/^\d{10}$/.test(phone)) return setError('Mobile number must be 10 digits')
    setBusy(true)
    try {
      const t = await queue.create({ doctorId, patientName: name, phone: phone || undefined, source: mode, mine: true })
      setToken(t)
      refreshQueues()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create token')
    } finally {
      setBusy(false)
    }
  }

  if (token) {
    return (
      <Card className="mx-auto max-w-md p-8 text-center print:border-0">
        <TicketCheck className="mx-auto size-9 text-success" aria-hidden />
        <p className="mt-3 text-sm text-muted-foreground">{hospitals?.find((h) => h.id === hospitalId)?.name}</p>
        <p className="mt-2 font-mono text-5xl font-semibold tracking-tight">{token.number}</p>
        <p className="mt-2 text-sm">
          {doctor?.name} · Room {doctor?.room}
        </p>
        <div className="mx-auto mt-6 w-fit rounded-xl border bg-white p-3">
          <QRCodeSVG value={`${origin}/queue?token=${token.id}`} size={148} aria-label="QR code to track this token" />
        </div>
        <p className="mt-3 text-xs text-muted-foreground">Scan to track your position live on your phone.</p>
        <div className="mt-6 flex justify-center gap-2 print:hidden">
          <Link href={`/queue?token=${token.id}`} className={buttonVariants()}>
            Track live
          </Link>
          <Button variant="outline" onClick={() => window.print()}>
            <Printer aria-hidden /> Print slip
          </Button>
          <Button variant="ghost" onClick={() => (setToken(null), setName(''), setPhone(''))}>
            New
          </Button>
        </div>
      </Card>
    )
  }

  return (
    <>
      <PageHeader
        eyebrow="Walk-in"
        title="Get a digital token"
        description="Scan the QR poster at reception or use the front-desk kiosk. No app or login required."
        action={<Tabs label="Check-in method" value={mode} onChange={setMode} items={[{ value: 'qr', label: 'QR check-in' }, { value: 'walk-in', label: 'Reception kiosk' }]} />}
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_320px]">
        <Card>
          <CardHeader title={mode === 'qr' ? 'You scanned the reception QR' : 'Kiosk registration'} description="Fill in a few details to join the queue." />
          <form onSubmit={submit} className="grid gap-4 p-5 sm:grid-cols-2" noValidate>
            <Field label="Hospital" htmlFor="c-hospital">
              <select id="c-hospital" value={hospitalId} onChange={(e) => (setHospitalId(e.target.value), setDoctorId(''))} className={inputClass}>
                {hospitals?.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Doctor" htmlFor="c-doctor">
              <select id="c-doctor" value={doctorId} onChange={(e) => setDoctorId(e.target.value)} className={inputClass}>
                <option value="">Select doctor</option>
                {hospitalDoctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} {d.status !== 'available' ? `(${d.status})` : ''}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Your name" htmlFor="c-name">
              <input id="c-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={inputClass} />
            </Field>
            <Field label="Mobile (optional)" htmlFor="c-phone" hint="Get SMS alerts even without a smartphone.">
              <input id="c-phone" inputMode="numeric" maxLength={10} value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))} className={inputClass} />
            </Field>
            {error && (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive sm:col-span-2">
                {error}
              </p>
            )}
            <div className="sm:col-span-2">
              <Button type="submit" disabled={busy} className="h-10 w-full sm:w-auto sm:px-6">
                {busy && <Loader2 className="animate-spin" aria-hidden />}
                Generate token
              </Button>
            </div>
          </form>
        </Card>

        <Card className="flex h-fit flex-col items-center p-6 text-center">
          <QrCode className="size-5 text-primary" aria-hidden />
          <p className="mt-2 font-medium">Reception QR poster</p>
          <p className="mt-1 text-sm text-muted-foreground">Print this and place it at the entrance.</p>
          <div className="mt-4 rounded-xl border bg-white p-3">
            <QRCodeSVG value={`${origin}/check-in?hospital=${hospitalId}`} size={160} aria-label="QR code for walk-in check-in" />
          </div>
        </Card>
      </div>
    </>
  )
}
