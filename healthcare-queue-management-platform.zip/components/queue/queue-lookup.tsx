'use client'

import { useRouter, useSearchParams } from 'next/navigation'
import { useState } from 'react'
import { Search } from 'lucide-react'
import { useAllQueues, useDoctors, useMyTokens } from '@/lib/hooks'
import { Card, CardHeader, PageHeader, StatusBadge, inputClass } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { TokenTracker } from './token-tracker'
import { cn } from '@/lib/utils'

export function QueueLookup() {
  const params = useSearchParams()
  const router = useRouter()
  const tokenId = params.get('token')
  const [input, setInput] = useState(tokenId ?? '')
  const { data: mine } = useMyTokens()
  const { data: queues } = useAllQueues()
  const { data: doctors } = useDoctors()

  const lookup = (e: React.FormEvent) => {
    e.preventDefault()
    const v = input.trim().toUpperCase()
    if (v) router.push(`/queue?token=${encodeURIComponent(v)}`)
  }

  return (
    <>
      <PageHeader eyebrow="Real-time" title="Live queue status" description="Enter your token number to see your position and AI-estimated waiting time. Updates automatically." />

      <div className="grid gap-6 lg:grid-cols-[1fr_380px]">
        <div className="flex flex-col gap-4">
          <form onSubmit={lookup} className="flex gap-2" role="search">
            <label htmlFor="token-input" className="sr-only">
              Token number
            </label>
            <input id="token-input" value={input} onChange={(e) => setInput(e.target.value)} placeholder="e.g. GM-014" className={cn(inputClass, 'font-mono uppercase')} />
            <Button type="submit" className="h-10 px-4">
              <Search aria-hidden /> Track
            </Button>
          </form>

          {mine && mine.length > 0 && (
            <div className="flex flex-wrap gap-2" aria-label="My tokens">
              {mine.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => (setInput(t.number), router.push(`/queue?token=${t.id}`))}
                  className={cn('rounded-full border px-3 py-1 font-mono text-sm', (tokenId === t.id || tokenId === t.number) && 'border-primary bg-secondary')}
                >
                  {t.number}
                </button>
              ))}
            </div>
          )}

          {tokenId ? (
            <TokenTracker tokenId={tokenId} />
          ) : (
            <Card className="p-6 text-sm text-muted-foreground">
              Try a demo token such as <span className="font-mono font-medium text-foreground">GM-014</span>, or get a new one from the booking page.
            </Card>
          )}
        </div>

        <Card className="h-fit">
          <CardHeader title="All queues right now" description="Now serving and queue length per doctor." />
          <ul className="divide-y">
            {queues?.map((q) => {
              const d = doctors?.find((x) => x.id === q.doctorId)
              return (
                <li key={q.doctorId} className="flex items-center justify-between gap-3 px-5 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{d?.name}</p>
                    <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
                      <StatusBadge status={q.doctorStatus} />
                      <span>{q.waiting.length} waiting</span>
                    </div>
                  </div>
                  <span className="font-mono text-lg font-semibold" aria-label={`Now serving ${q.serving?.number ?? 'none'}`}>
                    {q.serving?.number ?? '—'}
                  </span>
                </li>
              )
            })}
          </ul>
        </Card>
      </div>
    </>
  )
}
