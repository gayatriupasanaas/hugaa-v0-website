'use client'

import { useState } from 'react'
import { Send, Smartphone } from 'lucide-react'
import { ai } from '@/lib/api'
import { Card } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type Msg = { from: 'me' | 'huga'; text: string }

export function SmsSimulator() {
  const [msgs, setMsgs] = useState<Msg[]>([{ from: 'huga', text: 'HUGA: Text STATUS <TOKEN> to 56070 to check your queue. E.g. STATUS GM-014' }])
  const [text, setText] = useState('STATUS GM-014')
  const [busy, setBusy] = useState(false)

  const send = async (e: React.FormEvent) => {
    e.preventDefault()
    const v = text.trim()
    if (!v || busy) return
    setMsgs((m) => [...m, { from: 'me', text: v }])
    setText('')
    setBusy(true)
    try {
      const { reply } = await ai.sms(v)
      setMsgs((m) => [...m, { from: 'huga', text: reply }])
    } catch {
      setMsgs((m) => [...m, { from: 'huga', text: 'HUGA: Service unavailable. Please try again.' }])
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="grid gap-8 md:grid-cols-[340px_1fr] md:items-start">
      <Card className="mx-auto w-full max-w-[340px] overflow-hidden rounded-[2rem] border-4 border-foreground/80">
        <div className="flex items-center gap-2 border-b bg-muted px-4 py-3">
          <Smartphone className="size-4" aria-hidden />
          <span className="text-sm font-medium">56070 · HUGA</span>
        </div>
        <ol className="flex h-96 flex-col gap-2 overflow-y-auto p-4" aria-live="polite">
          {msgs.map((m, i) => (
            <li key={i} className={cn('max-w-[85%] rounded-2xl px-3 py-2 text-sm', m.from === 'me' ? 'self-end bg-primary text-primary-foreground' : 'self-start bg-muted')}>
              {m.text}
            </li>
          ))}
        </ol>
        <form onSubmit={send} className="flex gap-2 border-t p-3">
          <label htmlFor="sms-input" className="sr-only">
            SMS message
          </label>
          <input id="sms-input" value={text} onChange={(e) => setText(e.target.value)} className="h-9 flex-1 rounded-full border bg-background px-3 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/30" />
          <Button type="submit" size="icon" disabled={busy} aria-label="Send">
            <Send aria-hidden />
          </Button>
        </form>
      </Card>

      <div className="flex flex-col gap-4">
        <Card className="p-5">
          <h2 className="font-semibold">Supported commands</h2>
          <dl className="mt-3 space-y-3 text-sm">
            <div>
              <dt className="font-mono font-medium">STATUS GM-014</dt>
              <dd className="text-muted-foreground">Position in queue, estimated wait and the token currently being served.</dd>
            </div>
            <div>
              <dt className="font-mono font-medium">Automatic alerts</dt>
              <dd className="text-muted-foreground">An SMS is sent when 2 patients are ahead and again when your token is called.</dd>
            </div>
          </dl>
        </Card>
        <Card className="p-5 text-sm text-muted-foreground">
          In production, the Flask backend receives inbound SMS from a gateway (e.g. Twilio, MSG91) at <span className="font-mono text-foreground">POST /api/sms/inbound</span> and replies using the same queue data shown here.
        </Card>
      </div>
    </div>
  )
}
