'use client'

import { useEffect, useRef, useState } from 'react'
import { Maximize, Volume2, VolumeX } from 'lucide-react'
import { useAllQueues, useDoctors, useHospitals } from '@/lib/hooks'
import { StatusBadge } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function DisplayBoard() {
  const { data: hospitals } = useHospitals()
  const { data: doctors } = useDoctors()
  const { data: queues } = useAllQueues()
  const [hospitalId, setHospitalId] = useState('h1')
  const [voice, setVoice] = useState(false)
  const [now, setNow] = useState<Date | null>(null)
  const [flash, setFlash] = useState<string | null>(null)
  const lastServing = useRef<Record<string, string | undefined>>({})

  useEffect(() => {
    setNow(new Date())
    const id = setInterval(() => setNow(new Date()), 30_000)
    return () => clearInterval(id)
  }, [])

  const rows = (queues ?? []).filter((q) => doctors?.find((d) => d.id === q.doctorId)?.hospitalId === hospitalId)

  useEffect(() => {
    for (const q of rows) {
      const current = q.serving?.number
      const prev = lastServing.current[q.doctorId]
      if (current && prev && current !== prev) {
        const doc = doctors?.find((d) => d.id === q.doctorId)
        setFlash(q.doctorId)
        setTimeout(() => setFlash(null), 4000)
        if (voice && 'speechSynthesis' in window) {
          const spoken = current.split('').join(' ')
          window.speechSynthesis.speak(new SpeechSynthesisUtterance(`Token ${spoken}, please proceed to ${doc?.room ?? 'the room'}`))
        }
      }
      lastServing.current[q.doctorId] = current
    }
  }, [rows, doctors, voice])

  return (
    <main className="min-h-dvh bg-foreground p-4 text-background md:p-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <label htmlFor="display-hospital" className="sr-only">
              Hospital
            </label>
            <select
              id="display-hospital"
              value={hospitalId}
              onChange={(e) => setHospitalId(e.target.value)}
              className="rounded-lg border border-background/20 bg-transparent px-2 py-1 text-2xl font-semibold md:text-3xl [&>option]:text-foreground"
            >
              {hospitals?.map((h) => (
                <option key={h.id} value={h.id}>
                  {h.name}
                </option>
              ))}
            </select>
            <p className="mt-1 text-sm text-background/70">Please wait for your token to be called. Track live at huga.health/queue</p>
          </div>
          <div className="flex items-center gap-3">
            <p className="font-mono text-3xl tabular-nums" suppressHydrationWarning>
              {now?.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
            </p>
            <Button variant="secondary" size="icon" onClick={() => setVoice((v) => !v)} aria-label={voice ? 'Mute announcements' : 'Enable voice announcements'} aria-pressed={voice}>
              {voice ? <Volume2 aria-hidden /> : <VolumeX aria-hidden />}
            </Button>
            <Button variant="secondary" size="icon" onClick={() => document.documentElement.requestFullscreen?.()} aria-label="Full screen">
              <Maximize aria-hidden />
            </Button>
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-2">
          {rows.map((q) => {
            const d = doctors?.find((x) => x.id === q.doctorId)
            return (
              <section
                key={q.doctorId}
                aria-label={d?.name}
                className={cn('rounded-2xl border border-background/15 bg-background/5 p-6 transition-colors', flash === q.doctorId && 'border-primary bg-primary/30')}
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xl font-semibold">{d?.name}</p>
                    <p className="text-background/70">Room {d?.room}</p>
                  </div>
                  <div className="[&_span]:bg-background [&_span]:text-foreground">
                    <StatusBadge status={q.doctorStatus} />
                  </div>
                </div>
                <div className="mt-6 flex items-end justify-between gap-4">
                  <div>
                    <p className="text-sm uppercase tracking-widest text-background/60">Now serving</p>
                    <p className="font-mono text-6xl font-bold tracking-tight md:text-7xl" aria-live="assertive">
                      {q.serving?.number ?? '—'}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm uppercase tracking-widest text-background/60">Next</p>
                    <p className="font-mono text-2xl font-semibold">{q.waiting.slice(0, 3).map((w) => w.number).join('  ') || '—'}</p>
                    <p className="mt-1 text-sm text-background/70">{q.waiting.length} waiting</p>
                  </div>
                </div>
              </section>
            )
          })}
        </div>
      </div>
    </main>
  )
}
