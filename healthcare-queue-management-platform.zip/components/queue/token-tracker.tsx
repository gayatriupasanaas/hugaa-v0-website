'use client'

import { useEffect, useRef } from 'react'
import { BellRing, BrainCircuit, CheckCircle2, DoorOpen, Users } from 'lucide-react'
import { useDoctors, useEta, useQueue, useToken } from '@/lib/hooks'
import { queue } from '@/lib/api'
import { refreshQueues } from '@/lib/hooks'
import { usePrefs } from '@/lib/i18n'
import { Badge, Card, PriorityBadge, Skeleton, StatusBadge } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function TokenTracker({ tokenId, compact = false }: { tokenId: string; compact?: boolean }) {
  const { t } = usePrefs()
  const { data: token, isLoading } = useToken(tokenId)
  const { data: q } = useQueue(token?.doctorId ?? null)
  const { data: eta } = useEta(token?.status === 'waiting' ? tokenId : null)
  const { data: doctors } = useDoctors()
  const doctor = doctors?.find((d) => d.id === token?.doctorId)
  const notified = useRef(false)

  const ahead = token && q ? q.waiting.findIndex((w) => w.id === token.id) : -1
  const total = q ? q.waiting.length + (q.serving ? 1 : 0) : 0
  const progress = ahead >= 0 && total ? Math.round(((total - ahead - 1) / total) * 100) : token?.status === 'serving' ? 100 : 0

  useEffect(() => {
    if (!token || notified.current) return
    if ((ahead >= 0 && ahead <= 1) || token.status === 'serving') {
      notified.current = true
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification('HUGA: Your turn is near', { body: `${token.number} — please be near ${doctor?.room ?? 'the room'}.` })
      }
    }
  }, [ahead, token, doctor])

  if (isLoading) return <Skeleton className="h-72 w-full" />
  if (!token) {
    return (
      <Card className="p-6 text-sm text-muted-foreground" role="alert">
        Token not found. Check the number printed on your slip, e.g. GM-014.
      </Card>
    )
  }

  const near = token.status === 'serving' || (ahead >= 0 && ahead <= 1)

  return (
    <Card className={cn('overflow-hidden', near && 'border-primary')}>
      <div className={cn('flex flex-wrap items-start justify-between gap-4 p-5', near ? 'bg-primary text-primary-foreground' : 'bg-secondary')}>
        <div>
          <p className="text-xs font-medium opacity-80">{t('yourToken')}</p>
          <p className="font-mono text-4xl font-semibold tracking-tight md:text-5xl">{token.number}</p>
          <p className="mt-1 text-sm opacity-90">
            {doctor?.name ?? '—'} · {doctor?.room}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs font-medium opacity-80">{t('nowServing')}</p>
          <p className="font-mono text-2xl font-semibold" aria-live="polite">
            {q?.serving?.number ?? '—'}
          </p>
          {q && (
            <div className="mt-1 [&_span]:bg-background/90">
              <StatusBadge status={q.doctorStatus} />
            </div>
          )}
        </div>
      </div>

      <div className="p-5">
        {token.status === 'serving' ? (
          <p className="flex items-center gap-2 font-medium text-primary" role="status">
            <DoorOpen className="size-5" aria-hidden /> It is your turn. Please proceed to {doctor?.room}.
          </p>
        ) : token.status !== 'waiting' ? (
          <p className="flex items-center gap-2 font-medium" role="status">
            <CheckCircle2 className="size-5 text-success" aria-hidden /> Token {token.status}.
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
                  <Users className="size-3.5" aria-hidden /> {t('patientsAhead')}
                </p>
                <p className="text-3xl font-semibold tabular-nums">{Math.max(0, ahead)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{t('estimatedWait')}</p>
                <p className="text-3xl font-semibold tabular-nums text-primary">
                  {eta ? `~${eta.minutes}` : '…'} <span className="text-base font-medium">{t('minutes')}</span>
                </p>
                {eta && (
                  <p className="text-xs text-muted-foreground">
                    Range {eta.low}–{eta.high} min
                  </p>
                )}
              </div>
            </div>

            <div className="mt-5" aria-label={`Queue progress ${progress}%`} role="progressbar" aria-valuenow={progress} aria-valuemin={0} aria-valuemax={100}>
              <div className="h-2 overflow-hidden rounded-full bg-muted">
                <div className="h-full rounded-full bg-primary transition-all duration-700" style={{ width: `${progress}%` }} />
              </div>
            </div>

            {near && (
              <p className="mt-4 flex items-center gap-2 rounded-lg bg-warning/25 px-3 py-2 text-sm font-medium text-warning-foreground" role="status">
                <BellRing className="size-4" aria-hidden /> Your turn is approaching — please be near the consultation room.
              </p>
            )}

            {!compact && eta && (
              <div className="mt-5 rounded-lg border p-4">
                <div className="flex items-center justify-between">
                  <p className="flex items-center gap-1.5 text-sm font-medium">
                    <BrainCircuit className="size-4 text-primary" aria-hidden /> How this estimate works
                  </p>
                  <Badge tone={eta.source === 'ai' ? 'primary' : 'neutral'}>
                    {eta.source === 'ai' ? 'AI model' : 'Rule-based fallback'} · {Math.round(eta.confidence * 100)}%
                  </Badge>
                </div>
                <ul className="mt-3 space-y-1.5 text-sm">
                  {eta.factors.map((f) => (
                    <li key={f.label} className="flex justify-between gap-4">
                      <span className="text-muted-foreground">{f.label}</span>
                      <span className="font-medium">{f.impact}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}

        {!compact && (
          <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <PriorityBadge priority={token.priority} />
              <span>Source: {token.source}</span>
            </div>
            <div className="flex gap-2">
              {'Notification' in globalThis && (
                <Button variant="outline" onClick={() => Notification.requestPermission()}>
                  <BellRing aria-hidden /> Enable alerts
                </Button>
              )}
              {token.status === 'waiting' && (
                <Button
                  variant="destructive"
                  onClick={async () => {
                    if (!confirm(`Cancel token ${token.number}?`)) return
                    await queue.cancel(token.id)
                    refreshQueues()
                  }}
                >
                  Cancel token
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </Card>
  )
}
