'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { Clock, MapPin, Search, Siren, Star, Stethoscope } from 'lucide-react'
import { useDepartments, useDoctors, useHospitals } from '@/lib/hooks'
import { Badge, Card, EmptyState, PageHeader, Skeleton, StatusBadge, inputClass } from '@/components/ui-kit'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export function HospitalDirectory() {
  const { data: hospitals, isLoading } = useHospitals()
  const { data: departments } = useDepartments()
  const { data: doctors } = useDoctors()
  const [query, setQuery] = useState('')
  const [dept, setDept] = useState('all')
  const [sort, setSort] = useState<'distance' | 'wait' | 'rating'>('distance')

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    return (hospitals ?? [])
      .filter((h) => dept === 'all' || h.departments.includes(dept))
      .filter((h) => {
        if (!q) return true
        const docs = doctors?.filter((d) => d.hospitalId === h.id) ?? []
        return h.name.toLowerCase().includes(q) || h.city.toLowerCase().includes(q) || docs.some((d) => d.name.toLowerCase().includes(q))
      })
      .sort((a, b) => (sort === 'distance' ? a.distanceKm - b.distanceKm : sort === 'wait' ? a.avgWaitMin - b.avgWaitMin : b.rating - a.rating))
  }, [hospitals, doctors, query, dept, sort])

  return (
    <>
      <PageHeader eyebrow="Find care" title="Hospitals, clinics & doctors" description="Compare live waiting times, see which doctors are available now, and book in a tap." />

      <div className="mb-6 grid gap-3 md:grid-cols-[1fr_200px_180px]">
        <div className="relative">
          <label htmlFor="search" className="sr-only">
            Search hospitals or doctors
          </label>
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
          <input id="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by hospital, city or doctor" className={cn(inputClass, 'pl-9')} />
        </div>
        <label className="sr-only" htmlFor="dept">
          Department
        </label>
        <select id="dept" value={dept} onChange={(e) => setDept(e.target.value)} className={inputClass}>
          <option value="all">All departments</option>
          {departments?.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
        <label className="sr-only" htmlFor="sort">
          Sort by
        </label>
        <select id="sort" value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className={inputClass}>
          <option value="distance">Nearest first</option>
          <option value="wait">Shortest wait</option>
          <option value="rating">Top rated</option>
        </select>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-56" />
          ))}
        </div>
      ) : results.length === 0 ? (
        <Card>
          <EmptyState icon={Search} title="No matches" description="Try a different department or search term." />
        </Card>
      ) : (
        <ul className="grid gap-4 md:grid-cols-2">
          {results.map((h) => {
            const docs = (doctors ?? []).filter((d) => d.hospitalId === h.id && (dept === 'all' || d.departmentId === dept))
            return (
              <li key={h.id}>
                <Card className="flex h-full flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h2 className="font-semibold">{h.name}</h2>
                      <p className="mt-0.5 flex items-center gap-1 text-sm text-muted-foreground">
                        <MapPin className="size-3.5" aria-hidden /> {h.address} · {h.distanceKm} km
                      </p>
                    </div>
                    <span className="flex items-center gap-1 text-sm font-medium">
                      <Star className="size-4 fill-warning text-warning" aria-hidden /> {h.rating}
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <Badge tone={h.avgWaitMin > 30 ? 'warning' : 'success'}>
                      <Clock className="size-3" aria-hidden /> ~{h.avgWaitMin} min avg wait
                    </Badge>
                    <Badge>{h.hours}</Badge>
                    {h.emergency24x7 && (
                      <Badge tone="danger">
                        <Siren className="size-3" aria-hidden /> 24×7 Emergency
                      </Badge>
                    )}
                    {h.services.lab && <Badge tone="primary">Lab</Badge>}
                    {h.services.pharmacy && <Badge tone="primary">Pharmacy</Badge>}
                  </div>

                  <ul className="mt-4 flex-1 divide-y border-t">
                    {docs.slice(0, 3).map((d) => (
                      <li key={d.id} className="flex items-center justify-between gap-3 py-2.5">
                        <div className="flex min-w-0 items-center gap-2.5">
                          <Stethoscope className="size-4 shrink-0 text-muted-foreground" aria-hidden />
                          <div className="min-w-0">
                            <p className="truncate text-sm font-medium">{d.name}</p>
                            <p className="truncate text-xs text-muted-foreground">
                              {departments?.find((x) => x.id === d.departmentId)?.name} · {d.experienceYears} yrs · ₹{d.fee}
                            </p>
                          </div>
                        </div>
                        <StatusBadge status={d.status} />
                      </li>
                    ))}
                    {docs.length === 0 && <li className="py-3 text-sm text-muted-foreground">No doctors in this department.</li>}
                  </ul>

                  <div className="mt-4 flex gap-2">
                    <Link href={`/book?hospital=${h.id}`} className={cn(buttonVariants(), 'flex-1')}>
                      Book appointment
                    </Link>
                    <Link href={`/check-in?hospital=${h.id}`} className={cn(buttonVariants({ variant: 'outline' }), 'flex-1')}>
                      Walk-in token
                    </Link>
                  </div>
                </Card>
              </li>
            )
          })}
        </ul>
      )}
    </>
  )
}
