'use client'

import { useRouter } from 'next/navigation'
import { useState } from 'react'
import { Loader2 } from 'lucide-react'
import { auth } from '@/lib/api'
import { useMe } from '@/lib/hooks'
import { languages, usePrefs, type LangCode } from '@/lib/i18n'
import type { Role } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Card, Field, Tabs, inputClass } from '@/components/ui-kit'
import { dashboardPath } from '@/components/site-header'

const roleOptions: { value: Role; label: string }[] = [
  { value: 'patient', label: 'Patient' },
  { value: 'doctor', label: 'Doctor' },
  { value: 'staff', label: 'Hospital staff' },
  { value: 'lab', label: 'Lab technician' },
  { value: 'pharmacy', label: 'Pharmacy staff' },
  { value: 'admin', label: 'Administrator' },
]

type Mode = 'password' | 'otp' | 'register'

export function AuthPanel() {
  const router = useRouter()
  const { mutate } = useMe()
  const { lang, setLang } = usePrefs()
  const [mode, setMode] = useState<Mode>('password')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [otpSent, setOtpSent] = useState(false)
  const [role, setRole] = useState<Role>('patient')
  const [form, setForm] = useState({ identifier: '', password: '', phone: '', otp: '', name: '', email: '' })

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const run = async (fn: () => Promise<{ role: Role } | void>) => {
    setBusy(true)
    setError(null)
    try {
      const user = await fn()
      if (user) {
        await mutate()
        router.push(dashboardPath[user.role])
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Something went wrong')
    } finally {
      setBusy(false)
    }
  }

  const validPhone = /^\d{10}$/.test(form.phone)

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (mode === 'password') {
      if (!form.identifier.trim()) return setError('Enter your email or mobile number')
      if (form.password.length < 6) return setError('Password must be at least 6 characters')
      run(() => auth.login({ identifier: form.identifier.trim(), password: form.password, role }))
    } else if (mode === 'otp') {
      if (!validPhone) return setError('Enter a valid 10-digit mobile number')
      if (!otpSent) run(async () => void (await auth.requestOtp(form.phone), setOtpSent(true)))
      else run(() => auth.verifyOtp(form.phone, form.otp))
    } else {
      if (form.name.trim().length < 2) return setError('Enter your full name')
      if (!validPhone) return setError('Enter a valid 10-digit mobile number')
      if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) return setError('Enter a valid email address')
      if (form.password.length < 8) return setError('Password must be at least 8 characters')
      run(() => auth.register({ name: form.name.trim(), phone: form.phone, email: form.email, password: form.password, language: lang }))
    }
  }

  return (
    <Card className="w-full max-w-md p-6 md:p-8">
      <h1 className="text-2xl font-semibold tracking-tight">Welcome to HUGA</h1>
      <p className="mt-1 text-sm text-muted-foreground">Sign in to manage tokens, appointments and queues.</p>

      <div className="mt-6">
        <Tabs
          label="Sign-in method"
          value={mode}
          onChange={(m) => {
            setMode(m)
            setError(null)
            setOtpSent(false)
          }}
          items={[
            { value: 'password', label: 'Password' },
            { value: 'otp', label: 'Mobile OTP' },
            { value: 'register', label: 'Register' },
          ]}
        />
      </div>

      <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-4" noValidate>
        {mode === 'password' && (
          <>
            <Field label="Sign in as" htmlFor="role">
              <select id="role" value={role} onChange={(e) => setRole(e.target.value as Role)} className={inputClass}>
                {roleOptions.map((r) => (
                  <option key={r.value} value={r.value}>
                    {r.label}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Email or mobile number" htmlFor="identifier">
              <input id="identifier" autoComplete="username" value={form.identifier} onChange={set('identifier')} className={inputClass} />
            </Field>
            <Field label="Password" htmlFor="password">
              <input id="password" type="password" autoComplete="current-password" value={form.password} onChange={set('password')} className={inputClass} />
            </Field>
          </>
        )}

        {mode === 'otp' && (
          <>
            <Field label="Mobile number" htmlFor="phone" hint="We will send a 6-digit code by SMS.">
              <input id="phone" inputMode="numeric" autoComplete="tel" maxLength={10} value={form.phone} onChange={set('phone')} disabled={otpSent} className={inputClass} />
            </Field>
            {otpSent && (
              <Field label="One-time password" htmlFor="otp" hint="Demo code: 123456">
                <input id="otp" inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={form.otp} onChange={set('otp')} className={inputClass} autoFocus />
              </Field>
            )}
          </>
        )}

        {mode === 'register' && (
          <>
            <Field label="Full name" htmlFor="name">
              <input id="name" autoComplete="name" value={form.name} onChange={set('name')} className={inputClass} />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Mobile number" htmlFor="reg-phone">
                <input id="reg-phone" inputMode="numeric" maxLength={10} autoComplete="tel" value={form.phone} onChange={set('phone')} className={inputClass} />
              </Field>
              <Field label="Preferred language" htmlFor="reg-lang">
                <select id="reg-lang" value={lang} onChange={(e) => setLang(e.target.value as LangCode)} className={inputClass}>
                  {languages.map((l) => (
                    <option key={l.code} value={l.code}>
                      {l.label}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
            <Field label="Email (optional)" htmlFor="email">
              <input id="email" type="email" autoComplete="email" value={form.email} onChange={set('email')} className={inputClass} />
            </Field>
            <Field label="Password" htmlFor="reg-password" hint="At least 8 characters.">
              <input id="reg-password" type="password" autoComplete="new-password" value={form.password} onChange={set('password')} className={inputClass} />
            </Field>
          </>
        )}

        {error && (
          <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </p>
        )}

        <Button type="submit" disabled={busy} className="h-10 w-full text-sm">
          {busy && <Loader2 className="animate-spin" aria-hidden />}
          {mode === 'password' ? 'Sign in' : mode === 'otp' ? (otpSent ? 'Verify & sign in' : 'Send OTP') : 'Create account'}
        </Button>
      </form>
    </Card>
  )
}
