'use client'

import { useMemo, useState } from 'react'
import { Pill, Search } from 'lucide-react'
import { usePharmacies } from '@/lib/hooks'
import { Badge, Card, EmptyState, PageHeader, Skeleton, inputClass } from '@/components/ui-kit'
import { cn } from '@/lib/utils'

export function PharmacyFinder() {
  const { data: pharmacies, isLoading } = usePharmacies()
  const [q, setQ] = useState('')

  const matches = useMemo(() => {
    const term = q.trim().toLowerCase()
    return (pharmacies ?? []).flatMap((p) =>
      p.medicines
        .filter((m) => !term || m.name.toLowerCase().includes(term) || m.generic.toLowerCase().includes(term))
        .map((m) => ({ pharmacy: p, med: m, final: Math.round(m.price * (1 - m.discountPct / 100)) })),
    ).sort((a, b) => a.final - b.final)
  }, [pharmacies, q])

  return (
    <>
      <PageHeader eyebrow="Pharmacy" title="Find medicines nearby" description="Compare price, discount and live stock across hospital and Jan Aushadhi pharmacies." />

      <div className="relative mb-6 max-w-xl">
        <label htmlFor="med-search" className="sr-only">
          Search medicine
        </label>
        <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
        <input id="med-search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search e.g. Paracetamol, Metformin" className={cn(inputClass, 'pl-9')} />
      </div>

      {isLoading ? (
        <Skeleton className="h-72" />
      ) : matches.length === 0 ? (
        <Card>
          <EmptyState icon={Pill} title="No medicines found" description="Try the generic name instead of the brand." />
        </Card>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <caption className="sr-only">Medicine availability</caption>
            <thead className="border-b bg-muted/50 text-left text-xs text-muted-foreground">
              <tr>
                <th scope="col" className="px-5 py-3 font-medium">Medicine</th>
                <th scope="col" className="px-5 py-3 font-medium">Pharmacy</th>
                <th scope="col" className="px-5 py-3 font-medium">Price</th>
                <th scope="col" className="px-5 py-3 font-medium">Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {matches.map(({ pharmacy, med, final }) => (
                <tr key={`${pharmacy.id}-${med.id}`}>
                  <td className="px-5 py-3">
                    <p className="font-medium">{med.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {med.generic}
                      {med.prescriptionRequired && ' · Rx required'}
                    </p>
                  </td>
                  <td className="px-5 py-3">
                    <p>{pharmacy.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {pharmacy.city} · {pharmacy.open ? <span className="text-success">Open</span> : 'Closed'} · {pharmacy.hours}
                    </p>
                  </td>
                  <td className="px-5 py-3 tabular-nums">
                    <span className="font-medium">₹{final}</span>
                    {med.discountPct > 0 && (
                      <span className="ml-2 text-xs text-muted-foreground">
                        <s>₹{med.price}</s> {med.discountPct}% off
                      </span>
                    )}
                  </td>
                  <td className="px-5 py-3">
                    {med.stock === 0 ? <Badge tone="danger">Out of stock</Badge> : med.stock < 20 ? <Badge tone="warning">Low · {med.stock}</Badge> : <Badge tone="success">In stock</Badge>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </>
  )
}
