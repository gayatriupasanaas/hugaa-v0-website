'use client'

import { useState } from 'react'
import { useSWRConfig } from 'swr'
import { CheckCircle2, Clock, FlaskConical, Loader2, Users } from 'lucide-react'
import { labs as labsApi } from '@/lib/api'
import { useLabOrders, useLabs, useMe } from '@/lib/hooks'
import type { LabOrderStatus } from '@/lib/types'
import { Badge, Card, CardHeader, PageHeader, Skeleton } from '@/components/ui-kit'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export const labStatusLabel: Record<LabOrderStatus, string> = {
  booked: 'Booked',
  'sample-collected': 'Sample collected',
  processing: 'Processing',
  completed: 'Report ready',
}

export function LabBooking() {
  const { data: labList, isLoading } = useLabs()
  const { data: orders } = useLabOrders()
  const { data: me } = useMe()
  const { mutate } = useSWRConfig()
  const [labId, setLabId] = useState('l1')
  const [selected, setSelected] = useState<string[]>([])
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [booked, setBooked] = useState<string | null>(null)

  const lab = labList?.find((l) => l.id === labId)
  const chosen = lab?.tests.filter((t) => selected.includes(t.id)) ?? []
  const total = chosen.reduce((s, t) => s + t.price, 0)
  const queueForLab = orders?.filter((o) => o.labId === labId && o.status !== 'completed').length ?? 0

  const toggle = (id: string) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))

  const book = async () => {
    setError(null)
    setBusy(true)
    try {
      const order = (await labsApi.book({ labId, testIds: selected, patientName: me?.name ?? 'Guest' })) as { token: string }
      setBooked(order.token)
      setSelected([])
      mutate('lab-orders')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Booking failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <PageHeader eyebrow="Diagnostics" title="Book lab tests" description="See lab queue length and technician availability before you go. Get a lab token instantly." />

      {isLoading ? (
        <Skeleton className="h-80" />
      ) : (
        <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
          <div className="flex flex-col gap-4">
            <div className="grid gap-3 sm:grid-cols-3" role="radiogroup" aria-label="Lab">
              {labList?.map((l) => (
                <button
                  key={l.id}
                  type="button"
                  role="radio"
                  aria-checked={labId === l.id}
                  onClick={() => (setLabId(l.id), setSelected([]))}
                  className={cn('rounded-xl border bg-card p-4 text-left transition', labId === l.id ? 'border-primary ring-3 ring-primary/15' : 'hover:border-primary/40')}
                >
                  <p className="font-medium">{l.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {l.city} · {l.hours}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-1.5">
                    <Badge tone={l.waitMin > 20 ? 'warning' : 'success'}>
                      <Clock className="size-3" aria-hidden /> ~{l.waitMin} min
                    </Badge>
                    <Badge>
                      <Users className="size-3" aria-hidden /> {l.techniciansAvailable} techs
                    </Badge>
                  </div>
                </button>
              ))}
            </div>

            <Card>
              <CardHeader title="Available tests" description={`${queueForLab} patients currently in this lab's queue`} />
              <ul className="divide-y">
                {lab?.tests.map((t) => (
                  <li key={t.id}>
                    <label className="flex cursor-pointer items-center gap-3 px-5 py-3 hover:bg-muted/50">
                      <input type="checkbox" checked={selected.includes(t.id)} onChange={() => toggle(t.id)} className="size-4 accent-primary" />
                      <span className="flex-1">
                        <span className="block text-sm font-medium">{t.name}</span>
                        <span className="text-xs text-muted-foreground">
                          Report in ~{t.turnaroundHrs} h{t.fasting && ' · Fasting required'}
                        </span>
                      </span>
                      <span className="text-sm font-medium tabular-nums">₹{t.price}</span>
                    </label>
                  </li>
                ))}
              </ul>
            </Card>
          </div>

          <div className="flex flex-col gap-4">
            <Card className="h-fit p-5">
              {booked ? (
                <div className="text-center">
                  <CheckCircle2 className="mx-auto size-8 text-success" aria-hidden />
                  <p className="mt-2 text-sm text-muted-foreground">Your lab token</p>
                  <p className="font-mono text-3xl font-semibold">{booked}</p>
                  <Button variant="outline" className="mt-4" onClick={() => setBooked(null)}>
                    Book more tests
                  </Button>
                </div>
              ) : (
                <>
                  <p className="font-semibold">Summary</p>
                  <ul className="mt-3 space-y-1.5 text-sm">
                    {chosen.map((t) => (
                      <li key={t.id} className="flex justify-between gap-3">
                        <span className="text-muted-foreground">{t.name}</span>
                        <span>₹{t.price}</span>
                      </li>
                    ))}
                    {chosen.length === 0 && <li className="text-muted-foreground">No tests selected.</li>}
                  </ul>
                  {chosen.some((t) => t.fasting) && (
                    <p className="mt-3 rounded-lg bg-warning/25 px-3 py-2 text-xs text-warning-foreground">Fast for 10–12 hours before sample collection.</p>
                  )}
                  <div className="mt-4 flex justify-between border-t pt-3 font-semibold">
                    <span>Total</span>
                    <span className="tabular-nums">₹{total}</span>
                  </div>
                  {error && (
                    <p role="alert" className="mt-3 text-sm text-destructive">
                      {error}
                    </p>
                  )}
                  <Button className="mt-4 h-10 w-full" onClick={book} disabled={busy || chosen.length === 0}>
                    {busy ? <Loader2 className="animate-spin" aria-hidden /> : <FlaskConical aria-hidden />} Book & get lab token
                  </Button>
                </>
              )}
            </Card>

            <Card>
              <CardHeader title="Lab queue" />
              <ul className="divide-y">
                {orders
                  ?.filter((o) => o.labId === labId)
                  .map((o) => (
                    <li key={o.id} className="flex items-center justify-between px-5 py-2.5 text-sm">
                      <span className="font-mono font-medium">{o.token}</span>
                      <Badge tone={o.status === 'completed' ? 'success' : o.status === 'booked' ? 'neutral' : 'primary'}>{labStatusLabel[o.status]}</Badge>
                    </li>
                  ))}
              </ul>
            </Card>
          </div>
        </div>
      )}
    </>
  )
}
