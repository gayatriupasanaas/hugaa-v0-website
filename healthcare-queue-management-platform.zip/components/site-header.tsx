'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState } from 'react'
import { Accessibility, Activity, LogOut, Menu, X } from 'lucide-react'
import { auth } from '@/lib/api'
import { useMe } from '@/lib/hooks'
import { languages, usePrefs, type LangCode } from '@/lib/i18n'
import type { Role } from '@/lib/types'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export const dashboardPath: Record<Role, string> = {
  patient: '/patient',
  doctor: '/doctor',
  staff: '/staff',
  lab: '/lab-tech',
  pharmacy: '/pharmacy-staff',
  admin: '/admin',
}

export function SiteHeader() {
  const { t, lang, setLang, largeText, setLargeText, highContrast, setHighContrast } = usePrefs()
  const { data: user, mutate } = useMe()
  const pathname = usePathname()
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [a11yOpen, setA11yOpen] = useState(false)

  const nav = [
    { href: '/hospitals', label: t('hospitals') },
    { href: '/book', label: t('book') },
    { href: '/queue', label: t('liveQueue') },
    { href: '/labs', label: t('labs') },
    { href: '/pharmacy', label: t('pharmacy') },
  ]

  const signOut = async () => {
    await auth.logout()
    await mutate(null)
    router.push('/')
  }

  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-2 focus:rounded focus:bg-primary focus:px-3 focus:py-1 focus:text-primary-foreground">
        Skip to content
      </a>
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 font-semibold tracking-tight">
          <span className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground">
            <Activity className="size-4" aria-hidden />
          </span>
          <span className="text-lg">HUGA</span>
        </Link>

        <nav aria-label="Main" className="ml-4 hidden items-center gap-1 lg:flex">
          {nav.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              aria-current={pathname.startsWith(n.href) ? 'page' : undefined}
              className={cn(
                'rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground',
                pathname.startsWith(n.href) && 'bg-secondary text-secondary-foreground',
              )}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <label htmlFor="lang" className="sr-only">
            Language
          </label>
          <select
            id="lang"
            value={lang}
            onChange={(e) => setLang(e.target.value as LangCode)}
            className="h-9 rounded-lg border bg-background px-2 text-sm"
          >
            {languages.map((l) => (
              <option key={l.code} value={l.code}>
                {l.label}
              </option>
            ))}
          </select>

          <div className="relative">
            <button
              type="button"
              aria-label="Accessibility options"
              aria-expanded={a11yOpen}
              onClick={() => setA11yOpen((v) => !v)}
              className={buttonVariants({ variant: 'outline', size: 'icon-lg' })}
            >
              <Accessibility aria-hidden />
            </button>
            {a11yOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-xl border bg-popover p-3 shadow-lg">
                <p className="mb-2 text-xs font-semibold text-muted-foreground uppercase">Accessibility</p>
                <label className="flex items-center justify-between gap-2 py-1.5 text-sm">
                  Large text
                  <input type="checkbox" checked={largeText} onChange={(e) => setLargeText(e.target.checked)} className="size-4 accent-primary" />
                </label>
                <label className="flex items-center justify-between gap-2 py-1.5 text-sm">
                  High contrast
                  <input type="checkbox" checked={highContrast} onChange={(e) => setHighContrast(e.target.checked)} className="size-4 accent-primary" />
                </label>
              </div>
            )}
          </div>

          {user ? (
            <div className="hidden items-center gap-2 sm:flex">
              <Link href={dashboardPath[user.role]} className={buttonVariants({ variant: 'secondary', size: 'lg' })}>
                {t('dashboard')}
              </Link>
              <button type="button" onClick={signOut} aria-label={t('signOut')} className={buttonVariants({ variant: 'ghost', size: 'icon-lg' })}>
                <LogOut aria-hidden />
              </button>
            </div>
          ) : (
            <Link href="/login" className={cn(buttonVariants({ size: 'lg' }), 'hidden px-4 sm:inline-flex')}>
              {t('signIn')}
            </Link>
          )}

          <button
            type="button"
            className={cn(buttonVariants({ variant: 'ghost', size: 'icon-lg' }), 'lg:hidden')}
            aria-label="Toggle menu"
            aria-expanded={open}
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X aria-hidden /> : <Menu aria-hidden />}
          </button>
        </div>
      </div>

      {open && (
        <nav aria-label="Mobile" className="border-t px-4 py-3 lg:hidden">
          <ul className="flex flex-col gap-1">
            {nav.map((n) => (
              <li key={n.href}>
                <Link href={n.href} onClick={() => setOpen(false)} className="block rounded-md px-3 py-2 text-sm font-medium hover:bg-muted">
                  {n.label}
                </Link>
              </li>
            ))}
            <li>
              {user ? (
                <div className="flex gap-2 pt-2">
                  <Link href={dashboardPath[user.role]} onClick={() => setOpen(false)} className={cn(buttonVariants({ variant: 'secondary', size: 'lg' }), 'flex-1')}>
                    {t('dashboard')}
                  </Link>
                  <button type="button" onClick={signOut} className={buttonVariants({ variant: 'outline', size: 'lg' })}>
                    {t('signOut')}
                  </button>
                </div>
              ) : (
                <Link href="/login" onClick={() => setOpen(false)} className={cn(buttonVariants({ size: 'lg' }), 'mt-2 w-full')}>
                  {t('signIn')}
                </Link>
              )}
            </li>
          </ul>
        </nav>
      )}
    </header>
  )
}
