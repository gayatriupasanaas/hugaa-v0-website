import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'

const roles = [
  { title: 'Patients', body: 'Tokens, appointments, lab tests, prescriptions and notifications in one place.', href: '/patient' },
  { title: 'Doctors', body: 'Call the next patient, pause the queue and see today’s consultations.', href: '/doctor' },
  { title: 'Front-desk staff', body: 'Walk-in and physical tokens, priority and emergency cases, anomaly alerts.', href: '/staff' },
  { title: 'Lab technicians', body: 'Move samples through collection, processing and completion.', href: '/lab-tech' },
  { title: 'Pharmacy staff', body: 'Manage stock, prices and discounts, and verify prescriptions.', href: '/pharmacy-staff' },
  { title: 'Administrators', body: 'Analytics on volume, peak hours, utilization, no-shows and audit logs.', href: '/admin' },
]

export function LandingRoles() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16 md:px-6 md:py-24" aria-labelledby="roles-heading">
      <div className="grid gap-10 lg:grid-cols-3">
        <div>
          <p className="text-xs font-semibold tracking-wider text-primary uppercase">Built for everyone in the building</p>
          <h2 id="roles-heading" className="mt-2 text-3xl font-semibold tracking-tight text-balance">
            A dashboard for every role
          </h2>
          <p className="mt-3 text-muted-foreground text-pretty">
            Sign in with a role to explore. Each dashboard only shows what that role is permitted to see and change.
          </p>
          <Link href="/display" className="mt-6 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            Open public queue display <ArrowUpRight className="size-4" aria-hidden />
          </Link>
        </div>
        <ul className="grid gap-4 sm:grid-cols-2 lg:col-span-2">
          {roles.map((r) => (
            <li key={r.title}>
              <Link href={r.href} className="group flex h-full flex-col rounded-xl border bg-card p-5 transition hover:border-primary/40 hover:shadow-sm">
                <span className="flex items-center justify-between font-semibold">
                  {r.title}
                  <ArrowUpRight className="size-4 text-muted-foreground transition group-hover:text-primary" aria-hidden />
                </span>
                <span className="mt-1.5 text-sm text-muted-foreground">{r.body}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
