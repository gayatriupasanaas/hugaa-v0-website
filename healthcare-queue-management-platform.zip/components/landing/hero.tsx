'use client'

import Image from 'next/image'
import Link from 'next/link'
import { ArrowRight, QrCode, Ticket } from 'lucide-react'
import { usePrefs } from '@/lib/i18n'
import { useQueue } from '@/lib/hooks'
import { predictWait } from '@/lib/predict'
import { buttonVariants } from '@/components/ui/button'
import { Badge } from '@/components/ui-kit'
import { cn } from '@/lib/utils'

export function LandingHero() {
  const { t } = usePrefs()
  const { data: q } = useQueue('d1')
  const next = q?.waiting[2]
  const eta = q ? predictWait({ patientsAhead: 2, avgConsultMin: q.avgConsultMin, doctorStatus: q.doctorStatus, servingInProgress: true }) : null

  return (
    <section className="mx-auto grid max-w-7xl gap-10 px-4 pt-10 pb-16 md:px-6 lg:grid-cols-2 lg:items-center lg:pt-16">
      <div>
        <Badge tone="primary" className="mb-5">
          AI-powered patient flow for hospitals & clinics
        </Badge>
        <h1 className="text-4xl font-semibold tracking-tight text-balance md:text-5xl lg:text-6xl">{t('heroTitle')}</h1>
        <p className="mt-5 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty">{t('heroSub')}</p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/book" className={cn(buttonVariants({ size: 'lg' }), 'h-11 px-5 text-base')}>
            <Ticket aria-hidden />
            {t('getToken')}
          </Link>
          <Link href="/queue" className={cn(buttonVariants({ variant: 'outline', size: 'lg' }), 'h-11 px-5 text-base')}>
            {t('trackToken')}
            <ArrowRight aria-hidden />
          </Link>
          <Link href="/check-in" className={cn(buttonVariants({ variant: 'ghost', size: 'lg' }), 'h-11 px-4 text-base')}>
            <QrCode aria-hidden />
            {t('checkIn')}
          </Link>
        </div>
        <dl className="mt-10 grid max-w-md grid-cols-3 gap-6 border-t pt-6">
          {[
            ['38%', 'shorter waits'],
            ['6', 'languages'],
            ['24×7', 'SMS fallback'],
          ].map(([v, l]) => (
            <div key={l}>
              <dt className="text-xs text-muted-foreground">{l}</dt>
              <dd className="text-2xl font-semibold tabular-nums">{v}</dd>
            </div>
          ))}
        </dl>
      </div>

      <div className="relative">
        <div className="relative aspect-[4/3] overflow-hidden rounded-2xl border">
          <Image src="/images/hero-clinic.png" alt="A calm hospital waiting lobby with patients checking their phones" fill priority className="object-cover" sizes="(min-width: 1024px) 50vw, 100vw" />
        </div>

        <div className="absolute -bottom-6 left-4 w-64 rounded-2xl border bg-card p-4 shadow-xl lg:-left-6" aria-live="polite">
          <div className="flex items-center justify-between">
            <p className="text-xs font-medium text-muted-foreground">{t('nowServing')}</p>
            <span className="flex items-center gap-1 text-xs text-success">
              <span className="size-1.5 animate-pulse rounded-full bg-success" aria-hidden />
              Live
            </span>
          </div>
          <p className="mt-1 font-mono text-3xl font-semibold tracking-tight">{q?.serving?.number ?? '—'}</p>
          <div className="mt-3 flex items-end justify-between border-t pt-3">
            <div>
              <p className="text-xs text-muted-foreground">{t('yourToken')}</p>
              <p className="font-mono font-semibold">{next?.number ?? '—'}</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-muted-foreground">{t('estimatedWait')}</p>
              <p className="font-semibold text-primary">
                ~{eta?.minutes ?? '–'} {t('minutes')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
