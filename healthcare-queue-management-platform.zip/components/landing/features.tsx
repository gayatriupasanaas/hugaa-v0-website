import { BellRing, BrainCircuit, CalendarClock, FlaskConical, MessageSquareText, Pill, ShieldCheck, Timer } from 'lucide-react'

const features = [
  { icon: Timer, title: 'Live queue tracking', body: 'See the token being served, your position and patients ahead — refreshed in real time.' },
  { icon: BrainCircuit, title: 'AI waiting-time prediction', body: 'ETAs use queue size, consultation time, doctor status and historical demand, with a rule-based fallback.' },
  { icon: CalendarClock, title: 'Smart slot recommendation', body: 'Book the slots with the lowest predicted wait. Cancellations are offered to waitlisted patients.' },
  { icon: BellRing, title: 'Real-time notifications', body: 'Alerts when your turn approaches, rooms change or a queue is delayed.' },
  { icon: FlaskConical, title: 'Lab queues', body: 'Book tests and track sample collection, processing and report readiness.' },
  { icon: Pill, title: 'Pharmacy availability', body: 'Check stock, price and discounts, with prescription verification before dispensing.' },
  { icon: MessageSquareText, title: 'SMS & physical tokens', body: 'Patients without smartphones get printed tokens and SMS status updates.' },
  { icon: ShieldCheck, title: 'Privacy by default', body: 'Public screens show only token numbers. Role-based access for every staff member.' },
]

export function LandingFeatures() {
  return (
    <section className="border-y bg-card py-16 md:py-24" aria-labelledby="features-heading">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wider text-primary uppercase">One platform, whole journey</p>
          <h2 id="features-heading" className="mt-2 text-3xl font-semibold tracking-tight text-balance">
            From registration to pharmacy — transparent at every step
          </h2>
        </div>
        <ul className="mt-12 grid gap-px overflow-hidden rounded-2xl border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <li key={f.title} className="bg-card p-6">
              <f.icon className="size-5 text-primary" aria-hidden />
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
