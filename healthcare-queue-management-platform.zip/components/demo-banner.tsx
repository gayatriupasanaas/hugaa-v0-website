'use client'

import { useSyncExternalStore } from 'react'
import { WifiOff } from 'lucide-react'
import { DEMO_MODE } from '@/lib/api'

const subscribe = (cb: () => void) => {
  window.addEventListener('online', cb)
  window.addEventListener('offline', cb)
  return () => {
    window.removeEventListener('online', cb)
    window.removeEventListener('offline', cb)
  }
}

export function DemoBanner() {
  const online = useSyncExternalStore(subscribe, () => navigator.onLine, () => true)

  if (!online) {
    return (
      <div role="status" className="flex items-center justify-center gap-2 bg-warning px-4 py-1.5 text-xs font-medium text-warning-foreground">
        <WifiOff className="size-3.5" aria-hidden />
        You are offline. Showing last known queue data. For updates, SMS STATUS &lt;TOKEN&gt; to 56767.
      </div>
    )
  }

  if (!DEMO_MODE) return null

  return (
    <div className="bg-foreground px-4 py-1.5 text-center text-xs text-background">
      Demo mode — set <code className="font-mono">NEXT_PUBLIC_API_URL</code> to connect your Flask backend. Demo sign-in: any email, password 6+ chars · OTP 123456
    </div>
  )
}
