'use client'

import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { useMemo, useState } from 'react'
import { BrainCircuit, CheckCircle2, Loader2, Sparkles } from 'lucide-react'
import { appointments } from '@/lib/api'
import { refreshQueues, useDepartments, useDoctors, useHospitals, useMe, useSlots } from '@/lib/hooks'
import type { Token } from '@/lib/types'
import { Badge, Card, CardHeader, Field, PageHeader, Skeleton, StatusBadge, inputClass } from '@/components/ui-kit'
import { Button, buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const dayLabel = (offset: number) => {
  const d = new Date()
  d.setDate(d.getDate() + offset)
  return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' })
}

export function BookingFlow() {
  const params = useSearchParams()
  const { data: me } = useMe()
  const { data: hospitals } = useHospitals()
  const { data: departments } = useDepartments()
  const { data: doctors } = useDoctors()

  const [hospitalId, setHospitalId] = useState(params.get('hospital') ?? '')
  const [deptId, setDeptId] = useState('')
  const [doctorId, setDoctorId] = useState(params.get('doctor') ?? '')
  const [day, setDay] = useState(0)
  const [time, setTime] = useState('')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [booked, setBooked] = useState<Token | null>(null)

  const { data: slots, isLoading: slotsLoading } = useSlots(doctorId || null, day)

  const filteredDoctors = useMemo(
    () => (doctors ?? []).filter((d) => (!hospitalId || d.hospitalId === hospitalId) && (!deptId || d.departmentId === deptId)),
    [doctors, hospitalId, deptId],
  )
  const doctor = doctors?.find((d) => d.id === doctorId)
  const best = slots?.filter((s) => s.recommended)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    const patientName = name || me?.name || ''
    const patientPhone = phone || me?.phone || ''
    if (!doctorId) return setError('Choose a doctor')
    if (!time) return setError('Choose a time slot')
    if (patientName.trim().length < 2) return setError('Enter the patient name')
    if (!/^\d{10}$/.test(patientPhone)) return setError('Enter a valid 10-digit mobile number')
    setBusy(true)
    try {
      const tok = await appointments.book({ doctorId, dateLabel: dayLabel(day), time, patientName, phone: patientPhone })
      setBooked(tok)
      refreshQueues()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Booking failed')
    } finally {
      setBusy(false)
    }
  }

  if (booked) {
    return (
      <Card className="mx-auto max-w-lg p-8 text-center">
        <CheckCircle2 className="mx-auto size-10 text-success" aria-hidden />
        <h1 className="mt-4 text-2xl font-semibold">Appointment confirmed</h1>
        <p className="mt-1 text-muted-foreground">
          {doctor?.name} · {dayLabel(day)} at {time}
        </p>
        <div className="mx-auto mt-6 w-fit rounded-xl border-2 border-dashed border-primary/40 px-8 py-4">
          <p className="text-xs text-muted-foreground">Your digital token</p>
          <p className="font-mono text-4xl font-semibold tracking-tight">{booked.number}</p>
        </div>
        <p className="mt-4 text-sm text-muted-foreground">We will SMS you when your turn approaches. Room: {doctor?.room}</p>
        <div className="mt-6 flex justify-center gap-2">
          <Link href={`/queue?token=${booked.id}`} className={buttonVariants()}>
            Track live
          </Link>
          <Button variant="outline" onClick={() => (setBooked(null), setTime(''))}>
            Book another
          </Button>
        </div>
      </Card>
    )
  }

  return (
    <>
      <PageHeader eyebrow="Appointments" title="Book an appointment" description="Our AI recommends the slots with the shortest predicted wait based on historical demand." />

      <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1fr_380px]" noValidate>
        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader title="1. Choose a doctor" />
            <div className="grid gap-4 p-5 sm:grid-cols-2">
              <Field label="Hospital" htmlFor="b-hospital">
                <select id="b-hospital" value={hospitalId} onChange={(e) => (setHospitalId(e.target.value), setDoctorId(''))} className={inputClass}>
                  <option value="">Any hospital</option>
                  {hospitals?.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.name}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Department" htmlFor="b-dept">
                <select id="b-dept" value={deptId} onChange={(e) => (setDeptId(e.target.value), setDoctorId(''))} className={inputClass}>
                  <option value="">Any department</option>
                  {departments?.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </Field>
            </div>
            <ul className="grid gap-2 px-5 pb-5 sm:grid-cols-2" role="radiogroup" aria-label="Doctor">
              {filteredDoctors.map((d) => (
                <li key={d.id}>
                  <button
                    type="button"
                    role="radio"
                    aria-checked={doctorId === d.id}
                    onClick={() => (setDoctorId(d.id), setTime(''))}
                    className={cn(
                      'flex w-full flex-col items-start gap-1 rounded-lg border p-3 text-left transition outline-none focus-visible:ring-3 focus-visible:ring-ring/40',
                      doctorId === d.id ? 'border-primary bg-secondary' : 'hover:border-primary/40',
                    )}
                  >
                    <span className="flex w-full items-center justify-between gap-2">
                      <span className="text-sm font-medium">{d.name}</span>
                      <StatusBadge status={d.status} />
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {d.qualification} · {d.languages.join(', ')} · ₹{d.fee}
                    </span>
                  </button>
                </li>
              ))}
              {filteredDoctors.length === 0 && <li className="text-sm text-muted-foreground">No doctors match these filters.</li>}
            </ul>
          </Card>

          <Card>
            <CardHeader title="2. Pick a time" description={doctor ? `${doctor.hours} · ~${doctor.avgConsultMin} min per consultation` : 'Select a doctor first'} />
            <div className="p-5">
              <div className="flex gap-2 overflow-x-auto pb-1" role="radiogroup" aria-label="Day">
                {[0, 1, 2, 3, 4].map((o) => (
                  <button
                    key={o}
                    type="button"
                    role="radio"
                    aria-checked={day === o}
                    onClick={() => (setDay(o), setTime(''))}
                    className={cn('shrink-0 rounded-lg border px-3 py-2 text-sm font-medium', day === o ? 'border-primary bg-primary text-primary-foreground' : 'hover:border-primary/40')}
                  >
                    {o === 0 ? 'Today' : dayLabel(o)}
                  </button>
                ))}
              </div>

              {best && best.length > 0 && (
                <p className="mt-4 flex items-start gap-2 rounded-lg bg-secondary px-3 py-2 text-sm text-secondary-foreground">
                  <Sparkles className="mt-0.5 size-4 shrink-0" aria-hidden />
                  AI suggests {best.map((b) => b.time).join(', ')} — {best[0].reason ?? 'lowest predicted crowd'}.
                </p>
              )}

              {!doctorId ? null : slotsLoading ? (
                <Skeleton className="mt-4 h-32" />
              ) : (
                <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-6" role="radiogroup" aria-label="Time slot">
                  {slots?.map((s) => (
                    <button
                      key={s.time}
                      type="button"
                      role="radio"
                      aria-checked={time === s.time}
                      disabled={!s.available}
                      onClick={() => setTime(s.time)}
                      className={cn(
                        'relative rounded-lg border px-2 py-2 text-center text-sm transition disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground disabled:line-through',
                        time === s.time ? 'border-primary bg-primary text-primary-foreground' : s.recommended ? 'border-primary/50 bg-secondary' : 'hover:border-primary/40',
                      )}
                    >
                      <span className="block font-medium tabular-nums">{s.time}</span>
                      <span className={cn('block text-[11px]', time === s.time ? 'opacity-90' : 'text-muted-foreground')}>~{s.predictedWaitMin}m wait</span>
                      {s.recommended && <Sparkles className="absolute -top-1.5 -right-1.5 size-3.5 rounded-full bg-background text-primary" aria-label="Recommended" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </Card>
        </div>

        <Card className="h-fit lg:sticky lg:top-20">
          <CardHeader title="3. Patient details" />
          <div className="flex flex-col gap-4 p-5">
            <Field label="Patient name" htmlFor="b-name">
              <input id="b-name" value={name} placeholder={me?.name} onChange={(e) => setName(e.target.value)} autoComplete="name" className={inputClass} />
            </Field>
            <Field label="Mobile number" htmlFor="b-phone" hint="For SMS updates and reminders.">
              <input id="b-phone" inputMode="numeric" maxLength={10} value={phone} placeholder={me?.phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))} autoComplete="tel" className={inputClass} />
            </Field>

            <dl className="space-y-2 rounded-lg bg-muted p-4 text-sm">
              <div className="flex justify-between gap-4">
                <dt className="text-muted-foreground">Doctor</dt>
                <dd className="text-right font-medium">{doctor?.name ?? '—'}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted-foreground">When</dt>
                <dd className="font-medium">{time ? `${dayLabel(day)}, ${time}` : '—'}</dd>
              </div>
              <div className="flex justify-between gap-4">
                <dt className="text-muted-foreground">Consultation fee</dt>
                <dd className="font-medium">{doctor ? `₹${doctor.fee}` : '—'}</dd>
              </div>
              {time && (
                <div className="flex items-center justify-between gap-4 border-t pt-2">
                  <dt className="flex items-center gap-1 text-muted-foreground">
                    <BrainCircuit className="size-3.5" aria-hidden /> Predicted wait
                  </dt>
                  <dd>
                    <Badge tone="primary">~{slots?.find((s) => s.time === time)?.predictedWaitMin} min</Badge>
                  </dd>
                </div>
              )}
            </dl>

            {error && (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            )}
            <Button type="submit" disabled={busy} className="h-10">
              {busy && <Loader2 className="animate-spin" aria-hidden />}
              Confirm & get token
            </Button>
          </div>
        </Card>
      </form>
    </>
  )
}
