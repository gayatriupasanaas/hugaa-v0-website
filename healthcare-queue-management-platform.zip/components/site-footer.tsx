import Link from 'next/link'

export function SiteFooter() {
  return (
    <footer className="border-t bg-card">
      <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-8 text-sm text-muted-foreground md:flex-row md:items-center md:justify-between md:px-6">
        <p>
          HUGA helps with healthcare access and operations. It does not diagnose or prescribe. In an emergency call{' '}
          <strong className="text-foreground">108</strong>.
        </p>
        <nav aria-label="Footer" className="flex flex-wrap gap-4">
          <Link href="/display" className="hover:text-foreground">Queue display</Link>
          <Link href="/check-in" className="hover:text-foreground">QR check-in</Link>
          <Link href="/sms" className="hover:text-foreground">SMS updates</Link>
          <Link href="/login" className="hover:text-foreground">Staff sign in</Link>
        </nav>
      </div>
    </footer>
  )
}
