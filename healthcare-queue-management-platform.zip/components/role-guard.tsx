'use client'

import Link from 'next/link'
import { Lock } from 'lucide-react'
import { useMe } from '@/lib/hooks'
import type { Role } from '@/lib/types'
import { buttonVariants } from '@/components/ui/button'
import { Card, EmptyState, Skeleton } from '@/components/ui-kit'

export function RoleGuard({ roles, children }: { roles: Role[]; children: React.ReactNode }) {
  const { data: user, isLoading } = useMe()

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-1/3" />
        <Skeleton className="h-64 w-full" />
      </div>
    )
  }

  if (!user || !roles.includes(user.role)) {
    return (
      <Card className="mx-auto max-w-lg">
        <EmptyState
          icon={Lock}
          title={user ? 'You do not have access to this dashboard' : 'Sign in required'}
          description={`This area is restricted to: ${roles.join(', ')}. ${user ? `You are signed in as ${user.role}.` : ''}`}
          action={
            <Link href="/login" className={buttonVariants({ size: 'lg' })}>
              {user ? 'Switch account' : 'Sign in'}
            </Link>
          }
        />
      </Card>
    )
  }

  return <>{children}</>
}
