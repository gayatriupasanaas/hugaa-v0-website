'use client'

import { useRef, useState } from 'react'
import { Bot, Mic, MicOff, Send, Volume2, X } from 'lucide-react'
import { ai } from '@/lib/api'
import { languages, usePrefs } from '@/lib/i18n'
import { buttonVariants } from '@/components/ui/button'
import { cn } from '@/lib/utils'

type Msg = { role: 'user' | 'bot'; text: string }

type SpeechRecognitionLike = {
  lang: string
  interimResults: boolean
  start: () => void
  stop: () => void
  onresult: ((e: { results: { 0: { 0: { transcript: string } } } }) => void) | null
  onend: (() => void) | null
}

const suggestions = ['How long is my wait?', 'Which lab is least busy?', 'Is the pharmacy open?', 'Book a doctor']

export function AssistantWidget() {
  const { t, lang } = usePrefs()
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [listening, setListening] = useState(false)
  const [msgs, setMsgs] = useState<Msg[]>([
    { role: 'bot', text: 'Hi, I am the HUGA assistant. I can help with tokens, waiting times, doctors, labs and pharmacy. I do not give medical advice.' },
  ])
  const recRef = useRef<SpeechRecognitionLike | null>(null)
  const listRef = useRef<HTMLDivElement>(null)
  const speechLang = languages.find((l) => l.code === lang)?.speech ?? 'en-IN'

  const send = async (text: string) => {
    const q = text.trim()
    if (!q || busy) return
    setInput('')
    setMsgs((m) => [...m, { role: 'user', text: q }])
    setBusy(true)
    try {
      const { reply } = await ai.assistant(q, lang)
      setMsgs((m) => [...m, { role: 'bot', text: reply }])
    } catch {
      setMsgs((m) => [...m, { role: 'bot', text: 'Sorry, the assistant is unavailable right now. Please try again or ask at the front desk.' }])
    } finally {
      setBusy(false)
      requestAnimationFrame(() => listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' }))
    }
  }

  const speak = (text: string) => {
    if (!('speechSynthesis' in window)) return
    const u = new SpeechSynthesisUtterance(text)
    u.lang = speechLang
    window.speechSynthesis.cancel()
    window.speechSynthesis.speak(u)
  }

  const toggleMic = () => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike }
    const Ctor = w.SpeechRecognition ?? w.webkitSpeechRecognition
    if (!Ctor) {
      setMsgs((m) => [...m, { role: 'bot', text: 'Voice input is not supported in this browser. Please type your question.' }])
      return
    }
    if (listening) {
      recRef.current?.stop()
      return
    }
    const rec = new Ctor()
    rec.lang = speechLang
    rec.interimResults = false
    rec.onresult = (e) => send(e.results[0][0].transcript)
    rec.onend = () => setListening(false)
    recRef.current = rec
    setListening(true)
    rec.start()
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close assistant' : 'Open HUGA assistant'}
        aria-expanded={open}
        className="fixed right-4 bottom-4 z-50 grid size-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg transition hover:scale-105 focus-visible:ring-4 focus-visible:ring-ring/40 outline-none"
      >
        {open ? <X className="size-6" aria-hidden /> : <Bot className="size-6" aria-hidden />}
      </button>

      {open && (
        <section
          aria-label={t('assistant')}
          className="fixed right-4 bottom-22 z-50 flex h-[32rem] max-h-[calc(100dvh-7rem)] w-[calc(100vw-2rem)] max-w-sm flex-col overflow-hidden rounded-2xl border bg-card shadow-2xl"
        >
          <header className="flex items-center gap-3 border-b bg-primary px-4 py-3 text-primary-foreground">
            <Bot className="size-5" aria-hidden />
            <div>
              <h2 className="text-sm font-semibold">{t('assistant')}</h2>
              <p className="text-xs opacity-80">Voice & text · Operational help only</p>
            </div>
          </header>

          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
            {msgs.map((m, i) => (
              <div key={i} className={cn('flex gap-2', m.role === 'user' && 'justify-end')}>
                <div
                  className={cn(
                    'max-w-[85%] rounded-2xl px-3 py-2 text-sm leading-relaxed',
                    m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted',
                  )}
                >
                  {m.text}
                  {m.role === 'bot' && (
                    <button type="button" onClick={() => speak(m.text)} aria-label="Read aloud" className="ml-1 inline-flex align-middle text-muted-foreground hover:text-foreground">
                      <Volume2 className="size-3.5" aria-hidden />
                    </button>
                  )}
                </div>
              </div>
            ))}
            {busy && <p className="text-xs text-muted-foreground">Assistant is typing…</p>}
            {msgs.length === 1 && (
              <div className="flex flex-wrap gap-2 pt-1">
                {suggestions.map((s) => (
                  <button key={s} type="button" onClick={() => send(s)} className="rounded-full border px-3 py-1 text-xs hover:bg-muted">
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>

          <form
            className="flex items-center gap-2 border-t p-3"
            onSubmit={(e) => {
              e.preventDefault()
              send(input)
            }}
          >
            <button
              type="button"
              onClick={toggleMic}
              aria-label={listening ? 'Stop voice input' : 'Start voice input'}
              aria-pressed={listening}
              className={cn(buttonVariants({ variant: listening ? 'destructive' : 'outline', size: 'icon-lg' }), listening && 'pulse-ring')}
            >
              {listening ? <MicOff aria-hidden /> : <Mic aria-hidden />}
            </button>
            <label htmlFor="assistant-input" className="sr-only">
              Message
            </label>
            <input
              id="assistant-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={t('askAnything')}
              className="h-9 flex-1 rounded-lg border bg-background px-3 text-sm outline-none focus-visible:ring-3 focus-visible:ring-ring/30"
            />
            <button type="submit" disabled={!input.trim() || busy} aria-label="Send" className={buttonVariants({ size: 'icon-lg' })}>
              <Send aria-hidden />
            </button>
          </form>
        </section>
      )}
    </>
  )
}
