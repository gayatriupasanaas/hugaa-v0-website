export type Role = 'patient' | 'doctor' | 'staff' | 'lab' | 'pharmacy' | 'admin'

export type User = {
  id: string
  name: string
  email: string
  phone: string
  role: Role
  language: string
}

export type DoctorStatus = 'available' | 'on-break' | 'in-surgery' | 'off-duty'
export type Priority = 'normal' | 'priority' | 'emergency'
export type TokenStatus = 'waiting' | 'serving' | 'done' | 'skipped' | 'cancelled'

export type Department = {
  id: string
  name: string
  description: string
}

export type Hospital = {
  id: string
  name: string
  city: string
  address: string
  distanceKm: number
  rating: number
  departments: string[]
  avgWaitMin: number
  hours: string
  emergency24x7: boolean
  services: { opd: boolean; lab: boolean; pharmacy: boolean; emergency: boolean }
}

export type Doctor = {
  id: string
  name: string
  hospitalId: string
  departmentId: string
  qualification: string
  experienceYears: number
  languages: string[]
  status: DoctorStatus
  avgConsultMin: number
  room: string
  hours: string
  fee: number
}

export type Token = {
  id: string
  number: string
  doctorId: string
  patientName: string
  phone?: string
  priority: Priority
  status: TokenStatus
  source: 'app' | 'walk-in' | 'qr' | 'sms' | 'physical'
  createdAt: number
  calledAt?: number
  completedAt?: number
  appointmentTime?: string
}

export type QueueSnapshot = {
  doctorId: string
  doctorStatus: DoctorStatus
  serving: Token | null
  waiting: Token[]
  completedToday: number
  lastCallAt: number
  avgConsultMin: number
}

export type EtaPrediction = {
  minutes: number
  low: number
  high: number
  confidence: number
  source: 'ai' | 'rule-based'
  factors: { label: string; impact: string }[]
}

export type Slot = {
  time: string
  available: boolean
  predictedWaitMin: number
  recommended: boolean
  reason?: string
}

export type LabTest = { id: string; name: string; price: number; turnaroundHrs: number; fasting: boolean }
export type Lab = {
  id: string
  name: string
  hospitalId: string | null
  city: string
  hours: string
  techniciansAvailable: number
  waitMin: number
  tests: LabTest[]
}

export type LabOrderStatus = 'booked' | 'sample-collected' | 'processing' | 'completed'
export type LabOrder = {
  id: string
  token: string
  patientName: string
  labId: string
  testIds: string[]
  status: LabOrderStatus
  createdAt: number
}

export type Medicine = {
  id: string
  name: string
  generic: string
  price: number
  discountPct: number
  stock: number
  prescriptionRequired: boolean
}
export type Pharmacy = {
  id: string
  name: string
  hospitalId: string | null
  city: string
  hours: string
  open: boolean
  medicines: Medicine[]
}

export type Notification = {
  id: string
  title: string
  body: string
  type: 'queue' | 'appointment' | 'lab' | 'pharmacy' | 'system'
  createdAt: number
  read: boolean
}

export type Appointment = {
  id: string
  doctorId: string
  hospitalId: string
  date: string
  time: string
  status: 'upcoming' | 'completed' | 'cancelled' | 'no-show'
  tokenNumber?: string
}

export type AuditLog = { id: string; actor: string; role: Role; action: string; target: string; at: number }

export type QueueAlert = {
  id: string
  doctorId: string
  kind: 'stalled' | 'sla-breach' | 'slow'
  message: string
  severity: 'warning' | 'critical'
}
