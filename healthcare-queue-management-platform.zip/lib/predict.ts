import { hourlyDemand } from './mock-data'
import type { DoctorStatus, EtaPrediction, Priority, Slot } from './types'

const statusDelay: Record<DoctorStatus, { extra: number; label: string }> = {
  available: { extra: 0, label: 'Doctor available' },
  'on-break': { extra: 12, label: 'Doctor on short break' },
  'in-surgery': { extra: 35, label: 'Doctor in surgery / emergency' },
  'off-duty': { extra: 90, label: 'Doctor off duty' },
}

/**
 * Rule-based fallback for AI waiting-time prediction.
 * Mirrors the features the Flask model should use: queue size, consultation
 * duration, doctor status and historical hourly demand.
 */
export function predictWait(input: {
  patientsAhead: number
  avgConsultMin: number
  doctorStatus: DoctorStatus
  priority?: Priority
  hour?: number
  servingInProgress?: boolean
}): EtaPrediction {
  const hour = input.hour ?? new Date().getHours()
  const demand = hourlyDemand[hour] ?? 0.8
  const demandFactor = 0.85 + demand * 0.15
  const priorityFactor = input.priority === 'emergency' ? 0 : input.priority === 'priority' ? 0.5 : 1
  const status = statusDelay[input.doctorStatus]

  const base = input.patientsAhead * input.avgConsultMin * demandFactor * priorityFactor
  const current = input.servingInProgress ? input.avgConsultMin * 0.5 : 0
  const minutes = Math.max(0, Math.round(base + current + status.extra))

  const spread = Math.max(2, Math.round(minutes * (0.12 + input.patientsAhead * 0.01)))
  const confidence = Math.max(0.55, Math.min(0.96, 0.95 - input.patientsAhead * 0.02 - (status.extra > 0 ? 0.1 : 0)))

  return {
    minutes,
    low: Math.max(0, minutes - spread),
    high: minutes + spread,
    confidence,
    source: 'rule-based',
    factors: [
      { label: `${input.patientsAhead} patients ahead`, impact: `+${Math.round(base)} min` },
      { label: `Avg consultation ${input.avgConsultMin} min`, impact: 'baseline' },
      { label: status.label, impact: status.extra ? `+${status.extra} min` : 'no delay' },
      { label: demand > 1.1 ? 'Peak hour demand' : 'Normal hour demand', impact: `×${demandFactor.toFixed(2)}` },
    ],
  }
}

const fmtTime = (h: number, m: number) => {
  const period = h >= 12 ? 'PM' : 'AM'
  const hh = h % 12 === 0 ? 12 : h % 12
  return `${hh}:${m.toString().padStart(2, '0')} ${period}`
}

/** AI smart slot recommendation (fallback): scores slots by historical demand and availability. */
export function recommendSlots(doctorId: string, dateOffset: number, avgConsultMin: number): Slot[] {
  const seed = doctorId.charCodeAt(1) + dateOffset * 7
  const slots: Slot[] = []
  for (let h = 9; h < 18; h++) {
    for (const m of [0, 20, 40]) {
      const demand = hourlyDemand[h] ?? 0.8
      const pseudo = (seed * (h + 3) * (m + 11)) % 10
      const available = pseudo > 2
      slots.push({
        time: fmtTime(h, m),
        available,
        predictedWaitMin: Math.round(demand * avgConsultMin * 2.2 + (pseudo % 4)),
        recommended: false,
      })
    }
  }
  const ranked = slots
    .filter((s) => s.available)
    .sort((a, b) => a.predictedWaitMin - b.predictedWaitMin)
    .slice(0, 3)
  for (const r of ranked) {
    r.recommended = true
    r.reason = r.predictedWaitMin < 12 ? 'Lowest predicted wait' : 'Below-average demand'
  }
  return slots
}
