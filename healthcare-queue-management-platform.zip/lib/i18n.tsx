'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react'

export const languages = [
  { code: 'en', label: 'English', speech: 'en-IN' },
  { code: 'hi', label: 'हिन्दी', speech: 'hi-IN' },
  { code: 'ta', label: 'தமிழ்', speech: 'ta-IN' },
  { code: 'te', label: 'తెలుగు', speech: 'te-IN' },
  { code: 'kn', label: 'ಕನ್ನಡ', speech: 'kn-IN' },
  { code: 'ml', label: 'മലയാളം', speech: 'ml-IN' },
] as const

export type LangCode = (typeof languages)[number]['code']

const en = {
  hospitals: 'Hospitals',
  book: 'Book',
  liveQueue: 'Live Queue',
  labs: 'Labs',
  pharmacy: 'Pharmacy',
  dashboard: 'Dashboard',
  signIn: 'Sign in',
  signOut: 'Sign out',
  heroTitle: 'Know exactly when it is your turn.',
  heroSub: 'Digital tokens, live queues and AI-predicted waiting times for hospitals and clinics — so you can wait anywhere, not in a crowded hall.',
  getToken: 'Get a token',
  trackToken: 'Track my token',
  nowServing: 'Now serving',
  yourToken: 'Your token',
  patientsAhead: 'Patients ahead',
  estimatedWait: 'Estimated wait',
  minutes: 'min',
  search: 'Search',
  department: 'Department',
  doctor: 'Doctor',
  available: 'Available',
  onBreak: 'On break',
  inSurgery: 'In surgery',
  offDuty: 'Off duty',
  bookAppointment: 'Book appointment',
  recommended: 'AI recommended',
  confirm: 'Confirm',
  notifications: 'Notifications',
  assistant: 'HUGA Assistant',
  askAnything: 'Ask about your token, doctors, labs…',
  checkIn: 'QR check-in',
  display: 'Queue display',
}

type Dict = typeof en

const dict: Record<LangCode, Dict> = {
  en,
  hi: {
    hospitals: 'अस्पताल', book: 'बुक करें', liveQueue: 'लाइव कतार', labs: 'लैब', pharmacy: 'फार्मेसी', dashboard: 'डैशबोर्ड',
    signIn: 'साइन इन', signOut: 'साइन आउट',
    heroTitle: 'जानिए आपकी बारी कब आएगी।',
    heroSub: 'अस्पतालों और क्लीनिकों के लिए डिजिटल टोकन, लाइव कतार और AI से अनुमानित प्रतीक्षा समय — भीड़ भरे हॉल में नहीं, कहीं भी इंतज़ार करें।',
    getToken: 'टोकन लें', trackToken: 'मेरा टोकन देखें', nowServing: 'अभी सेवा में', yourToken: 'आपका टोकन',
    patientsAhead: 'आगे मरीज़', estimatedWait: 'अनुमानित प्रतीक्षा', minutes: 'मिनट', search: 'खोजें', department: 'विभाग', doctor: 'डॉक्टर',
    available: 'उपलब्ध', onBreak: 'विराम पर', inSurgery: 'सर्जरी में', offDuty: 'ड्यूटी से बाहर', bookAppointment: 'अपॉइंटमेंट बुक करें',
    recommended: 'AI अनुशंसित', confirm: 'पुष्टि करें', notifications: 'सूचनाएँ', assistant: 'HUGA सहायक',
    askAnything: 'टोकन, डॉक्टर, लैब के बारे में पूछें…', checkIn: 'QR चेक-इन', display: 'कतार डिस्प्ले',
  },
  ta: {
    hospitals: 'மருத்துவமனைகள்', book: 'முன்பதிவு', liveQueue: 'நேரடி வரிசை', labs: 'ஆய்வகங்கள்', pharmacy: 'மருந்தகம்', dashboard: 'டாஷ்போர்டு',
    signIn: 'உள்நுழை', signOut: 'வெளியேறு',
    heroTitle: 'உங்கள் முறை எப்போது என்று சரியாக அறியுங்கள்.',
    heroSub: 'மருத்துவமனைகளுக்கான டிஜிட்டல் டோக்கன்கள், நேரடி வரிசைகள் மற்றும் AI கணிக்கும் காத்திருப்பு நேரம் — நெரிசலான அறையில் அல்ல, எங்கும் காத்திருங்கள்.',
    getToken: 'டோக்கன் பெறுக', trackToken: 'என் டோக்கனைக் கண்காணி', nowServing: 'இப்போது சேவையில்', yourToken: 'உங்கள் டோக்கன்',
    patientsAhead: 'முன்னால் நோயாளிகள்', estimatedWait: 'மதிப்பிடப்பட்ட காத்திருப்பு', minutes: 'நிமி', search: 'தேடு', department: 'துறை', doctor: 'மருத்துவர்',
    available: 'கிடைக்கிறார்', onBreak: 'இடைவேளை', inSurgery: 'அறுவை சிகிச்சையில்', offDuty: 'பணியில் இல்லை', bookAppointment: 'சந்திப்பை முன்பதிவு செய்',
    recommended: 'AI பரிந்துரை', confirm: 'உறுதிசெய்', notifications: 'அறிவிப்புகள்', assistant: 'HUGA உதவியாளர்',
    askAnything: 'டோக்கன், மருத்துவர், ஆய்வகம் பற்றி கேளுங்கள்…', checkIn: 'QR செக்-இன்', display: 'வரிசை காட்சி',
  },
  te: {
    hospitals: 'ఆసుపత్రులు', book: 'బుక్ చేయండి', liveQueue: 'లైవ్ క్యూ', labs: 'ల్యాబ్‌లు', pharmacy: 'ఫార్మసీ', dashboard: 'డాష్‌బోర్డ్',
    signIn: 'సైన్ ఇన్', signOut: 'సైన్ అవుట్',
    heroTitle: 'మీ వంతు ఎప్పుడో ఖచ్చితంగా తెలుసుకోండి.',
    heroSub: 'ఆసుపత్రులు మరియు క్లినిక్‌ల కోసం డిజిటల్ టోకెన్లు, లైవ్ క్యూలు మరియు AI అంచనా వేసిన వేచి ఉండే సమయం — రద్దీ హాల్లో కాదు, ఎక్కడైనా వేచి ఉండండి.',
    getToken: 'టోకెన్ పొందండి', trackToken: 'నా టోకెన్ ట్రాక్ చేయండి', nowServing: 'ఇప్పుడు సేవలో', yourToken: 'మీ టోకెన్',
    patientsAhead: 'ముందున్న రోగులు', estimatedWait: 'అంచనా వేచి ఉండే సమయం', minutes: 'ని', search: 'వెతకండి', department: 'విభాగం', doctor: 'డాక్టర్',
    available: 'అందుబాటులో', onBreak: 'విరామంలో', inSurgery: 'శస్త్రచికిత్సలో', offDuty: 'డ్యూటీలో లేరు', bookAppointment: 'అపాయింట్‌మెంట్ బుక్ చేయండి',
    recommended: 'AI సిఫార్సు', confirm: 'నిర్ధారించండి', notifications: 'నోటిఫికేషన్లు', assistant: 'HUGA సహాయకుడు',
    askAnything: 'టోకెన్, డాక్టర్లు, ల్యాబ్‌ల గురించి అడగండి…', checkIn: 'QR చెక్-ఇన్', display: 'క్యూ డిస్ప్లే',
  },
  kn: {
    hospitals: 'ಆಸ್ಪತ್ರೆಗಳು', book: 'ಬುಕ್ ಮಾಡಿ', liveQueue: 'ಲೈವ್ ಸರತಿ', labs: 'ಪ್ರಯೋಗಾಲಯಗಳು', pharmacy: 'ಔಷಧಾಲಯ', dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
    signIn: 'ಸೈನ್ ಇನ್', signOut: 'ಸೈನ್ ಔಟ್',
    heroTitle: 'ನಿಮ್ಮ ಸರದಿ ಯಾವಾಗ ಎಂದು ನಿಖರವಾಗಿ ತಿಳಿಯಿರಿ.',
    heroSub: 'ಆಸ್ಪತ್ರೆ ಮತ್ತು ಕ್ಲಿನಿಕ್‌ಗಳಿಗಾಗಿ ಡಿಜಿಟಲ್ ಟೋಕನ್‌ಗಳು, ಲೈವ್ ಸರತಿಗಳು ಮತ್ತು AI ಅಂದಾಜು ಕಾಯುವ ಸಮಯ — ಜನದಟ್ಟಣೆಯ ಹಾಲ್‌ನಲ್ಲಿ ಅಲ್ಲ, ಎಲ್ಲಿಯಾದರೂ ಕಾಯಿರಿ.',
    getToken: 'ಟೋಕನ್ ಪಡೆಯಿರಿ', trackToken: 'ನನ್ನ ಟೋಕನ್ ಟ್ರ್ಯಾಕ್ ಮಾಡಿ', nowServing: 'ಈಗ ಸೇವೆಯಲ್ಲಿ', yourToken: 'ನಿಮ್ಮ ಟೋಕನ್',
    patientsAhead: 'ಮುಂದಿರುವ ರೋಗಿಗಳು', estimatedWait: 'ಅಂದಾಜು ಕಾಯುವಿಕೆ', minutes: 'ನಿ', search: 'ಹುಡುಕಿ', department: 'ವಿಭಾಗ', doctor: 'ವೈದ್ಯರು',
    available: 'ಲಭ್ಯವಿದೆ', onBreak: 'ವಿರಾಮದಲ್ಲಿ', inSurgery: 'ಶಸ್ತ್ರಚಿಕಿತ್ಸೆಯಲ್ಲಿ', offDuty: 'ಕರ್ತವ್ಯದಲ್ಲಿಲ್ಲ', bookAppointment: 'ಅಪಾಯಿಂಟ್‌ಮೆಂಟ್ ಬುಕ್ ಮಾಡಿ',
    recommended: 'AI ಶಿಫಾರಸು', confirm: 'ದೃಢೀಕರಿಸಿ', notifications: 'ಅಧಿಸೂಚನೆಗಳು', assistant: 'HUGA ಸಹಾಯಕ',
    askAnything: 'ಟೋಕನ್, ವೈದ್ಯರು, ಲ್ಯಾಬ್ ಬಗ್ಗೆ ಕೇಳಿ…', checkIn: 'QR ಚೆಕ್-ಇನ್', display: 'ಸರತಿ ಪ್ರದರ್ಶನ',
  },
  ml: {
    hospitals: 'ആശുപത്രികൾ', book: 'ബുക്ക് ചെയ്യുക', liveQueue: 'തത്സമയ ക്യൂ', labs: 'ലാബുകൾ', pharmacy: 'ഫാർമസി', dashboard: 'ഡാഷ്‌ബോർഡ്',
    signIn: 'സൈൻ ഇൻ', signOut: 'സൈൻ ഔട്ട്',
    heroTitle: 'നിങ്ങളുടെ ഊഴം എപ്പോഴാണെന്ന് കൃത്യമായി അറിയുക.',
    heroSub: 'ആശുപത്രികൾക്കും ക്ലിനിക്കുകൾക്കുമായി ഡിജിറ്റൽ ടോക്കണുകൾ, തത്സമയ ക്യൂ, AI പ്രവചിക്കുന്ന കാത്തിരിപ്പ് സമയം — തിരക്കേറിയ ഹാളിലല്ല, എവിടെയും കാത്തിരിക്കാം.',
    getToken: 'ടോക്കൺ നേടുക', trackToken: 'എന്റെ ടോക്കൺ ട്രാക്ക് ചെയ്യുക', nowServing: 'ഇപ്പോൾ സേവനത്തിൽ', yourToken: 'നിങ്ങളുടെ ടോക്കൺ',
    patientsAhead: 'മുന്നിലുള്ള രോഗികൾ', estimatedWait: 'കണക്കാക്കിയ കാത്തിരിപ്പ്', minutes: 'മി', search: 'തിരയുക', department: 'വകുപ്പ്', doctor: 'ഡോക്ടർ',
    available: 'ലഭ്യമാണ്', onBreak: 'ഇടവേളയിൽ', inSurgery: 'ശസ്ത്രക്രിയയിൽ', offDuty: 'ഡ്യൂട്ടിയിലില്ല', bookAppointment: 'അപ്പോയിന്റ്മെന്റ് ബുക്ക് ചെയ്യുക',
    recommended: 'AI ശുപാർശ', confirm: 'സ്ഥിരീകരിക്കുക', notifications: 'അറിയിപ്പുകൾ', assistant: 'HUGA സഹായി',
    askAnything: 'ടോക്കൺ, ഡോക്ടർമാർ, ലാബ് എന്നിവയെക്കുറിച്ച് ചോദിക്കുക…', checkIn: 'QR ചെക്ക്-ഇൻ', display: 'ക്യൂ ഡിസ്‌പ്ലേ',
  },
}

type Prefs = { lang: LangCode; largeText: boolean; highContrast: boolean }

type Ctx = Prefs & {
  t: (key: keyof Dict) => string
  setLang: (l: LangCode) => void
  setLargeText: (v: boolean) => void
  setHighContrast: (v: boolean) => void
}

const I18nContext = createContext<Ctx | null>(null)

export function PreferencesProvider({ children }: { children: React.ReactNode }) {
  const [prefs, setPrefs] = useState<Prefs>({ lang: 'en', largeText: false, highContrast: false })

  useEffect(() => {
    const el = document.documentElement
    el.lang = prefs.lang
    el.classList.toggle('a11y-large', prefs.largeText)
    el.classList.toggle('a11y-contrast', prefs.highContrast)
  }, [prefs])

  const t = useCallback((key: keyof Dict) => dict[prefs.lang][key] ?? en[key], [prefs.lang])

  const value = useMemo<Ctx>(
    () => ({
      ...prefs,
      t,
      setLang: (lang) => setPrefs((p) => ({ ...p, lang })),
      setLargeText: (largeText) => setPrefs((p) => ({ ...p, largeText })),
      setHighContrast: (highContrast) => setPrefs((p) => ({ ...p, highContrast })),
    }),
    [prefs, t],
  )

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>
}

export function usePrefs() {
  const ctx = useContext(I18nContext)
  if (!ctx) throw new Error('usePrefs must be used inside PreferencesProvider')
  return ctx
}
