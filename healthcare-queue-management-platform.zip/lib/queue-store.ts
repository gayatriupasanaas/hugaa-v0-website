import { doctors } from './mock-data'
import type { DoctorStatus, Priority, QueueAlert, QueueSnapshot, Token } from './types'

/**
 * In-browser demo queue engine. Used only when NEXT_PUBLIC_API_URL is not set.
 * The Flask backend should expose equivalent behaviour and push events
 * (token created / called / completed / skipped / cancelled / doctor status).
 */

const DEMO_CALL_INTERVAL_MS = 25_000
const SLA_THRESHOLD_MIN = 45

type QueueState = {
  doctorStatus: DoctorStatus
  tokens: Token[]
  lastCallAt: number
  counter: number
  completedToday: number
  autoAdvance: boolean
}

const prefix: Record<string, string> = {
  gm: 'GM', cardio: 'CA', ortho: 'OR', peds: 'PD', ophth: 'EY', derm: 'DR', ent: 'EN', gyn: 'GY',
}

const names = ['Arun', 'Divya', 'Mohammed', 'Sneha', 'Karthik', 'Pooja', 'Rajesh', 'Anjali', 'Vijay', 'Deepa', 'Imran', 'Revathi', 'Harish', 'Nandini']

const state = new Map<string, QueueState>()
export const myTokenIds = new Set<string>()

function seed() {
  const now = Date.now()
  doctors.forEach((doc, i) => {
    const p = prefix[doc.departmentId] ?? 'TK'
    const waitingCount = [7, 6, 4, 3, 5, 2, 4, 9][i] ?? 3
    const startNum = 10 + i
    const tokens: Token[] = []
    tokens.push({
      id: `${doc.id}-t${startNum}`, number: `${p}-${String(startNum).padStart(3, '0')}`, doctorId: doc.id,
      patientName: names[i % names.length], priority: 'normal', status: 'serving', source: 'app',
      createdAt: now - 50 * 60_000, calledAt: now - 3 * 60_000,
    })
    for (let k = 1; k <= waitingCount; k++) {
      const n = startNum + k
      tokens.push({
        id: `${doc.id}-t${n}`, number: `${p}-${String(n).padStart(3, '0')}`, doctorId: doc.id,
        patientName: names[(i + k) % names.length],
        priority: k === 3 && i === 0 ? 'priority' : 'normal',
        status: 'waiting', source: k % 3 === 0 ? 'walk-in' : 'app', createdAt: now - (40 - k * 4) * 60_000,
      })
    }
    state.set(doc.id, {
      doctorStatus: doc.status,
      tokens,
      lastCallAt: doc.status === 'available' ? now : now - 38 * 60_000,
      counter: startNum + waitingCount,
      completedToday: 14 + i * 3,
      autoAdvance: doc.status === 'available',
    })
  })
  // The demo patient's own token, positioned 4th in Dr. Rao's queue.
  const d1 = state.get('d1')!
  const mine = d1.tokens[4]
  mine.patientName = 'You'
  myTokenIds.add(mine.id)
}
seed()

const rank: Record<Priority, number> = { emergency: 0, priority: 1, normal: 2 }
const order = (a: Token, b: Token) => rank[a.priority] - rank[b.priority] || a.createdAt - b.createdAt

function advance(q: QueueState) {
  const now = Date.now()
  for (const t of q.tokens) {
    if (t.status === 'serving') {
      t.status = 'done'
      t.completedAt = now
      q.completedToday++
    }
  }
  const next = q.tokens.filter((t) => t.status === 'waiting').sort(order)[0]
  if (next) {
    next.status = 'serving'
    next.calledAt = now
  }
  q.lastCallAt = now
}

function tick(q: QueueState) {
  if (!q.autoAdvance || q.doctorStatus !== 'available') return
  const elapsed = Date.now() - q.lastCallAt
  const steps = Math.min(3, Math.floor(elapsed / DEMO_CALL_INTERVAL_MS))
  for (let i = 0; i < steps; i++) advance(q)
}

export function snapshot(doctorId: string): QueueSnapshot {
  const q = state.get(doctorId)
  const doc = doctors.find((d) => d.id === doctorId)
  if (!q || !doc) throw new Error('Queue not found')
  tick(q)
  return {
    doctorId,
    doctorStatus: q.doctorStatus,
    serving: q.tokens.find((t) => t.status === 'serving') ?? null,
    waiting: q.tokens.filter((t) => t.status === 'waiting').sort(order).map((t) => ({ ...t })),
    completedToday: q.completedToday,
    lastCallAt: q.lastCallAt,
    avgConsultMin: doc.avgConsultMin,
  }
}

export function findToken(tokenId: string): Token | undefined {
  for (const q of state.values()) {
    tick(q)
    const t = q.tokens.find((x) => x.id === tokenId || x.number === tokenId)
    if (t) return { ...t }
  }
}

export function createToken(input: {
  doctorId: string
  patientName: string
  phone?: string
  priority?: Priority
  source: Token['source']
  appointmentTime?: string
  mine?: boolean
}): Token {
  const q = state.get(input.doctorId)
  const doc = doctors.find((d) => d.id === input.doctorId)
  if (!q || !doc) throw new Error('Doctor not found')
  if (!input.patientName.trim()) throw new Error('Patient name is required')
  q.counter++
  const token: Token = {
    id: `${doc.id}-t${q.counter}`,
    number: `${prefix[doc.departmentId] ?? 'TK'}-${String(q.counter).padStart(3, '0')}`,
    doctorId: doc.id,
    patientName: input.patientName.trim(),
    phone: input.phone,
    priority: input.priority ?? 'normal',
    status: 'waiting',
    source: input.source,
    createdAt: Date.now(),
    appointmentTime: input.appointmentTime,
  }
  q.tokens.push(token)
  if (input.mine) myTokenIds.add(token.id)
  return { ...token }
}

function mutateToken(tokenId: string, fn: (t: Token, q: QueueState) => void) {
  for (const q of state.values()) {
    const t = q.tokens.find((x) => x.id === tokenId)
    if (t) {
      fn(t, q)
      return
    }
  }
  throw new Error('Token not found')
}

export const queueActions = {
  callNext(doctorId: string) {
    const q = state.get(doctorId)
    if (!q) throw new Error('Queue not found')
    advance(q)
  },
  complete(tokenId: string) {
    mutateToken(tokenId, (t, q) => {
      if (t.status !== 'serving') throw new Error('Only the serving token can be completed')
      t.status = 'done'
      t.completedAt = Date.now()
      q.completedToday++
    })
  },
  skip(tokenId: string) {
    mutateToken(tokenId, (t) => {
      if (t.status === 'done' || t.status === 'cancelled') throw new Error('Token already closed')
      t.status = 'skipped'
    })
  },
  cancel(tokenId: string) {
    mutateToken(tokenId, (t) => {
      if (t.status === 'done') throw new Error('Completed tokens cannot be cancelled')
      t.status = 'cancelled'
    })
  },
  setPriority(tokenId: string, priority: Priority) {
    mutateToken(tokenId, (t) => {
      if (t.status !== 'waiting') throw new Error('Priority can only change while waiting')
      t.priority = priority
    })
  },
  setDoctorStatus(doctorId: string, status: DoctorStatus) {
    const q = state.get(doctorId)
    if (!q) throw new Error('Queue not found')
    q.doctorStatus = status
    q.autoAdvance = status === 'available'
    if (status === 'available') q.lastCallAt = Date.now()
  },
}

export function detectAlerts(): QueueAlert[] {
  const alerts: QueueAlert[] = []
  for (const doc of doctors) {
    const s = snapshot(doc.id)
    const idleMin = (Date.now() - s.lastCallAt) / 60_000
    const tailWait = s.waiting.length * s.avgConsultMin
    if (s.waiting.length > 0 && idleMin > s.avgConsultMin * 3) {
      alerts.push({
        id: `stall-${doc.id}`, doctorId: doc.id, kind: 'stalled', severity: 'critical',
        message: `${doc.name}'s queue has not moved for ${Math.round(idleMin)} min (${s.waiting.length} waiting).`,
      })
    }
    if (tailWait > SLA_THRESHOLD_MIN) {
      alerts.push({
        id: `sla-${doc.id}`, doctorId: doc.id, kind: 'sla-breach', severity: 'warning',
        message: `Last patient for ${doc.name} will wait ~${tailWait} min (SLA ${SLA_THRESHOLD_MIN} min).`,
      })
    }
  }
  return alerts
}
