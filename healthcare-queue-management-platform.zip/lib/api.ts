import * as mock from './mock-data'
import { predictWait, recommendSlots } from './predict'
import { createToken, detectAlerts, findToken, myTokenIds, queueActions, snapshot } from './queue-store'
import { answerLocally } from './assistant-rules'
import type {
  DoctorStatus,
  EtaPrediction,
  LabOrderStatus,
  Medicine,
  Priority,
  Role,
  Token,
  User,
} from './types'

/**
 * Base URL of the Flask backend, e.g. https://huga-api.onrender.com
 * When unset, the app runs in demo mode with an in-browser simulation.
 */
export const API_BASE = (process.env.NEXT_PUBLIC_API_URL ?? '').replace(/\/$/, '')
export const DEMO_MODE = !API_BASE

export class ApiError extends Error {
  constructor(message: string, public status = 0) {
    super(message)
  }
}

async function http<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...init,
    credentials: 'include',
    headers: { 'Content-Type': 'application/json', ...(init?.headers ?? {}) },
  })
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(body?.error ?? `Request failed (${res.status})`, res.status)
  return body as T
}

/** Reads fall back to local demo data if the backend is unreachable (AI fallback system). */
async function read<T>(path: string, demo: () => T): Promise<T> {
  if (DEMO_MODE) return demo()
  try {
    return await http<T>(path)
  } catch (err) {
    if (err instanceof ApiError && err.status >= 400 && err.status < 500) throw err
    console.warn('[huga] backend unreachable, using fallback for', path)
    return demo()
  }
}

async function write<T>(path: string, body: unknown, demo: () => T, method = 'POST'): Promise<T> {
  if (DEMO_MODE) {
    await new Promise((r) => setTimeout(r, 250))
    return demo()
  }
  return http<T>(path, { method, body: JSON.stringify(body) })
}

const wait = (v: unknown) => v

/* ---------------- Auth ---------------- */

const DEMO_SESSION_KEY = 'huga-demo-session'

function demoUser(): User | null {
  if (typeof window === 'undefined') return null
  const raw = window.sessionStorage.getItem(DEMO_SESSION_KEY)
  return raw ? (JSON.parse(raw) as User) : null
}

function setDemoUser(u: User | null) {
  if (u) window.sessionStorage.setItem(DEMO_SESSION_KEY, JSON.stringify(u))
  else window.sessionStorage.removeItem(DEMO_SESSION_KEY)
}

const demoNames: Record<Role, string> = {
  patient: 'Priya Patient',
  doctor: 'Dr. Ananya Rao',
  staff: 'Nisha (Front desk)',
  lab: 'Ramesh (Lab)',
  pharmacy: 'Kiran (Pharmacy)',
  admin: 'System Admin',
}

export const auth = {
  me: () => read<User | null>('/api/auth/me', demoUser),
  login: (input: { identifier: string; password: string; role: Role }) =>
    write<User>('/api/auth/login', input, () => {
      if (input.password.length < 6) throw new ApiError('Invalid credentials', 401)
      const u: User = {
        id: `u-${input.role}`, name: demoNames[input.role], email: input.identifier.includes('@') ? input.identifier : 'demo@huga.health',
        phone: input.identifier.includes('@') ? '9876543210' : input.identifier, role: input.role, language: 'en',
      }
      setDemoUser(u)
      return u
    }),
  requestOtp: (phone: string) =>
    write<{ sent: boolean }>('/api/auth/otp/request', { phone }, () => ({ sent: true })),
  verifyOtp: (phone: string, code: string) =>
    write<User>('/api/auth/otp/verify', { phone, code }, () => {
      if (code !== '123456') throw new ApiError('Incorrect OTP. In demo mode use 123456.', 401)
      const u: User = { id: 'u-patient', name: demoNames.patient, email: '', phone, role: 'patient', language: 'en' }
      setDemoUser(u)
      return u
    }),
  register: (input: { name: string; phone: string; email: string; password: string; language: string }) =>
    write<User>('/api/auth/register', input, () => {
      const u: User = { id: 'u-patient', name: input.name, email: input.email, phone: input.phone, role: 'patient', language: input.language }
      setDemoUser(u)
      return u
    }),
  logout: () => write<{ ok: boolean }>('/api/auth/logout', {}, () => (setDemoUser(null), { ok: true })),
}

/* ---------------- Directory ---------------- */

export const directory = {
  hospitals: () => read('/api/hospitals', () => mock.hospitals),
  departments: () => read('/api/departments', () => mock.departments),
  doctors: () => read('/api/doctors', () => mock.doctors.map((d) => ({ ...d, status: snapshot(d.id).doctorStatus }))),
  labs: () => read('/api/labs', () => mock.labs),
  pharmacies: () => read('/api/pharmacies', () => mock.pharmacies.map((p) => ({ ...p, medicines: [...p.medicines] }))),
}

/* ---------------- Queue & tokens ---------------- */

export const queue = {
  get: (doctorId: string) => read(`/api/queues/${doctorId}`, () => snapshot(doctorId)),
  all: () => read('/api/queues', () => mock.doctors.map((d) => snapshot(d.id))),
  token: (tokenId: string) => read<Token | null>(`/api/tokens/${tokenId}`, () => findToken(tokenId) ?? null),
  mine: () =>
    read<Token[]>('/api/tokens/mine', () =>
      [...myTokenIds].map((id) => findToken(id)).filter((t): t is Token => Boolean(t)),
    ),
  create: (input: {
    doctorId: string
    patientName: string
    phone?: string
    priority?: Priority
    source: Token['source']
    appointmentTime?: string
    mine?: boolean
  }) => write<Token>('/api/tokens', input, () => createToken(input)),
  callNext: (doctorId: string) => write(`/api/queues/${doctorId}/next`, {}, () => wait(queueActions.callNext(doctorId))),
  complete: (tokenId: string) => write(`/api/tokens/${tokenId}/complete`, {}, () => wait(queueActions.complete(tokenId))),
  skip: (tokenId: string) => write(`/api/tokens/${tokenId}/skip`, {}, () => wait(queueActions.skip(tokenId))),
  cancel: (tokenId: string) => write(`/api/tokens/${tokenId}/cancel`, {}, () => wait(queueActions.cancel(tokenId))),
  setPriority: (tokenId: string, priority: Priority) =>
    write(`/api/tokens/${tokenId}/priority`, { priority }, () => wait(queueActions.setPriority(tokenId, priority)), 'PATCH'),
  setDoctorStatus: (doctorId: string, status: DoctorStatus) =>
    write(`/api/doctors/${doctorId}/status`, { status }, () => wait(queueActions.setDoctorStatus(doctorId, status)), 'PATCH'),
  alerts: () => read('/api/queues/alerts', detectAlerts),
}

/* ---------------- AI ---------------- */

export const ai = {
  eta: (tokenId: string) =>
    read<EtaPrediction | null>(`/api/ai/eta/${tokenId}`, () => {
      const t = findToken(tokenId)
      if (!t) return null
      const s = snapshot(t.doctorId)
      const ahead = s.waiting.findIndex((w) => w.id === t.id)
      return predictWait({
        patientsAhead: Math.max(0, ahead),
        avgConsultMin: s.avgConsultMin,
        doctorStatus: s.doctorStatus,
        priority: t.priority,
        servingInProgress: Boolean(s.serving),
      })
    }),
  slots: (doctorId: string, dateOffset: number) =>
    read(`/api/ai/slots?doctor=${doctorId}&day=${dateOffset}`, () => {
      const doc = mock.doctorById(doctorId)
      return recommendSlots(doctorId, dateOffset, doc?.avgConsultMin ?? 10)
    }),
  assistant: (message: string, language: string) =>
    write<{ reply: string }>('/api/ai/assistant', { message, language }, () => ({ reply: answerLocally(message) })),
  sms: (message: string) =>
    write<{ reply: string }>('/api/sms/simulate', { message }, () => {
      const code = message.trim().toUpperCase().split(/\s+/)[1]
      const t = code ? findToken(code) : undefined
      if (!t) return { reply: 'HUGA: Token not found. Send STATUS <TOKEN>, e.g. STATUS GM-014' }
      const s = snapshot(t.doctorId)
      const ahead = s.waiting.findIndex((w) => w.id === t.id)
      if (t.status === 'serving') return { reply: `HUGA: ${t.number} is being served now. Please go to the room.` }
      if (ahead < 0) return { reply: `HUGA: ${t.number} status: ${t.status}.` }
      const eta = predictWait({ patientsAhead: ahead, avgConsultMin: s.avgConsultMin, doctorStatus: s.doctorStatus })
      return { reply: `HUGA: ${t.number} - ${ahead} ahead, ~${eta.minutes} min. Now serving ${s.serving?.number ?? '-'}.` }
    }),
}

/* ---------------- Appointments ---------------- */

export const appointments = {
  mine: () => read('/api/appointments/mine', () => mock.appointments.map((a) => ({ ...a }))),
  book: (input: { doctorId: string; dateLabel: string; time: string; patientName: string; phone: string }) =>
    write<Token>('/api/appointments', input, () => {
      const doc = mock.doctorById(input.doctorId)
      if (!doc) throw new ApiError('Doctor not found', 404)
      if (!/^\d{10}$/.test(input.phone)) throw new ApiError('Enter a valid 10-digit mobile number', 422)
      mock.appointments.unshift({
        id: `a${Date.now()}`, doctorId: doc.id, hospitalId: doc.hospitalId, date: input.dateLabel, time: input.time, status: 'upcoming',
      })
      return createToken({
        doctorId: doc.id, patientName: input.patientName, phone: input.phone, source: 'app', appointmentTime: `${input.dateLabel} ${input.time}`, mine: true,
      })
    }),
  cancel: (id: string) =>
    write(`/api/appointments/${id}/cancel`, {}, () => {
      const a = mock.appointments.find((x) => x.id === id)
      if (a) a.status = 'cancelled'
      return a
    }),
}

/* ---------------- Labs ---------------- */

export const labs = {
  orders: () => read('/api/lab-orders', () => mock.labOrders.map((o) => ({ ...o }))),
  book: (input: { labId: string; testIds: string[]; patientName: string }) =>
    write('/api/lab-orders', input, () => {
      if (!input.testIds.length) throw new ApiError('Select at least one test', 422)
      const order = {
        id: `lo${Date.now()}`, token: `LB-${105 + mock.labOrders.length}`, patientName: input.patientName,
        labId: input.labId, testIds: input.testIds, status: 'booked' as LabOrderStatus, createdAt: Date.now(),
      }
      mock.labOrders.push(order)
      return order
    }),
  setStatus: (id: string, status: LabOrderStatus) =>
    write(`/api/lab-orders/${id}`, { status }, () => {
      const o = mock.labOrders.find((x) => x.id === id)
      if (o) o.status = status
      return o
    }, 'PATCH'),
}

/* ---------------- Pharmacy ---------------- */

export const pharmacy = {
  updateMedicine: (pharmacyId: string, med: Medicine) =>
    write(`/api/pharmacies/${pharmacyId}/medicines/${med.id}`, med, () => {
      if (med.price <= 0) throw new ApiError('Price must be greater than 0', 422)
      if (med.stock < 0 || !Number.isInteger(med.stock)) throw new ApiError('Stock must be a whole number', 422)
      if (med.discountPct < 0 || med.discountPct > 90) throw new ApiError('Discount must be 0–90%', 422)
      const p = mock.pharmacies.find((x) => x.id === pharmacyId)
      if (!p) throw new ApiError('Pharmacy not found', 404)
      const i = p.medicines.findIndex((m) => m.id === med.id)
      if (i >= 0) p.medicines[i] = med
      else p.medicines.push(med)
      return med
    }, 'PUT'),
  verifyPrescription: (code: string) =>
    write<{ valid: boolean; patient?: string; doctor?: string; items?: string[] }>('/api/prescriptions/verify', { code }, () =>
      /^RX-\d{4}$/i.test(code.trim())
        ? { valid: true, patient: 'Priya Patient', doctor: 'Dr. Ananya Rao', items: ['Amoxicillin 500mg × 10', 'Paracetamol 500mg × 6'] }
        : { valid: false },
    ),
}

/* ---------------- Misc ---------------- */

export const misc = {
  notifications: () => read('/api/notifications', () => mock.notifications),
  auditLogs: () => read('/api/audit-logs', () => mock.auditLogs),
  analytics: () => read('/api/analytics', () => mock.analytics),
  feedback: (input: { rating: number; comment: string; service: string }) =>
    write('/api/feedback', input, () => {
      if (input.rating < 1 || input.rating > 5) throw new ApiError('Choose a rating from 1 to 5', 422)
      return { ok: true }
    }),
}
