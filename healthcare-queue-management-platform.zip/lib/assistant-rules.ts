import { doctors, labs, pharmacies } from './mock-data'
import { predictWait } from './predict'
import { findToken, myTokenIds, snapshot } from './queue-store'

const unsafe = /(diagnos|prescri|what medicine|which medicine|dosage|dose|cure|treat(ment)? for|am i sick|symptom)/i
const emergency = /(chest pain|can'?t breathe|unconscious|bleeding heavily|stroke|heart attack|emergency|suicid)/i

/** Rule-based fallback for the HUGA assistant. Operational queries only — never medical advice. */
export function answerLocally(message: string): string {
  const m = message.toLowerCase()

  if (emergency.test(m)) {
    return 'This may be an emergency. Please call 108 (ambulance) immediately or go to the nearest emergency department. Hospital staff have been notified to assist you at the front desk.'
  }
  if (unsafe.test(m)) {
    return "I can't provide diagnosis, prescriptions or medical advice. I can help you book a doctor, check your queue, find a lab or check medicine availability."
  }
  if (/(token|queue|wait|turn|how long|eta)/.test(m)) {
    const id = [...myTokenIds].at(-1)
    const t = id ? findToken(id) : undefined
    if (!t) return "You don't have an active token. Book an appointment or scan the hospital QR code to get one."
    const s = snapshot(t.doctorId)
    if (t.status === 'serving') return `Your token ${t.number} is being served now. Please proceed to the consultation room.`
    const ahead = s.waiting.findIndex((w) => w.id === t.id)
    const eta = predictWait({ patientsAhead: Math.max(0, ahead), avgConsultMin: s.avgConsultMin, doctorStatus: s.doctorStatus })
    return `Token ${t.number}: ${ahead} patients ahead of you. Estimated wait is about ${eta.minutes} minutes (range ${eta.low}–${eta.high}). Now serving ${s.serving?.number ?? '—'}.`
  }
  if (/(lab|test|blood|x-?ray|report)/.test(m)) {
    const best = [...labs].sort((a, b) => a.waitMin - b.waitMin)[0]
    return `${best.name} currently has the shortest lab wait (~${best.waitMin} min, ${best.techniciansAvailable} technicians available). You can book tests from the Labs page.`
  }
  if (/(pharmacy|medicine|tablet|stock|drug)/.test(m)) {
    const open = pharmacies.filter((p) => p.open).map((p) => p.name)
    return `Open pharmacies right now: ${open.join(', ')}. Search medicine availability and prices on the Pharmacy page.`
  }
  if (/(doctor|book|appointment|slot)/.test(m)) {
    const free = doctors.filter((d) => d.status === 'available').slice(0, 3).map((d) => d.name)
    return `Available now: ${free.join(', ')}. Go to Book to see AI-recommended slots with the lowest predicted wait.`
  }
  if (/(hour|open|timing|close)/.test(m)) {
    return 'City General Hospital OPD runs 8:00 AM – 8:00 PM, emergency is 24×7. Pharmacy is open 24 hours; lab 7:00 AM – 9:00 PM.'
  }
  if (/(hello|hi|namaste|vanakkam|help)/.test(m)) {
    return 'Hello! I am the HUGA assistant. Ask me about your token, waiting time, doctors, lab tests, pharmacy or hospital timings.'
  }
  return 'I can help with tokens, queue status, waiting times, appointments, labs, pharmacy and timings. Could you rephrase your question?'
}
