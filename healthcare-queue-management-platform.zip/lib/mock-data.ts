import type {
  Appointment,
  AuditLog,
  Department,
  Doctor,
  Hospital,
  Lab,
  LabOrder,
  Notification,
  Pharmacy,
} from './types'

export const departments: Department[] = [
  { id: 'gm', name: 'General Medicine', description: 'Fever, infections, routine check-ups' },
  { id: 'cardio', name: 'Cardiology', description: 'Heart and blood pressure care' },
  { id: 'ortho', name: 'Orthopedics', description: 'Bones, joints and fractures' },
  { id: 'peds', name: 'Pediatrics', description: 'Care for infants and children' },
  { id: 'ophth', name: 'Ophthalmology', description: 'Eye examinations and vision care' },
  { id: 'derm', name: 'Dermatology', description: 'Skin, hair and nail conditions' },
  { id: 'ent', name: 'ENT', description: 'Ear, nose and throat' },
  { id: 'gyn', name: 'Gynecology', description: "Women's health and maternity" },
]

export const hospitals: Hospital[] = [
  {
    id: 'h1',
    name: 'City General Hospital',
    city: 'Chennai',
    address: '12 Anna Salai, Teynampet',
    distanceKm: 2.4,
    rating: 4.5,
    departments: ['gm', 'cardio', 'ortho', 'peds', 'ophth', 'ent'],
    avgWaitMin: 34,
    hours: '8:00 AM – 8:00 PM',
    emergency24x7: true,
    services: { opd: true, lab: true, pharmacy: true, emergency: true },
  },
  {
    id: 'h2',
    name: 'Sunrise Multispeciality Clinic',
    city: 'Chennai',
    address: '45 OMR, Thoraipakkam',
    distanceKm: 6.1,
    rating: 4.3,
    departments: ['gm', 'derm', 'gyn', 'peds'],
    avgWaitMin: 18,
    hours: '9:00 AM – 9:00 PM',
    emergency24x7: false,
    services: { opd: true, lab: true, pharmacy: true, emergency: false },
  },
  {
    id: 'h3',
    name: 'Lakeview Medical Centre',
    city: 'Bengaluru',
    address: '8 Outer Ring Rd, Bellandur',
    distanceKm: 3.8,
    rating: 4.6,
    departments: ['gm', 'cardio', 'ophth', 'ortho', 'gyn'],
    avgWaitMin: 52,
    hours: '24 hours',
    emergency24x7: true,
    services: { opd: true, lab: true, pharmacy: false, emergency: true },
  },
  {
    id: 'h4',
    name: 'Government District Hospital',
    city: 'Hyderabad',
    address: 'Koti Main Rd, Sultan Bazar',
    distanceKm: 9.2,
    rating: 4.0,
    departments: ['gm', 'peds', 'ortho', 'ent', 'gyn', 'derm'],
    avgWaitMin: 67,
    hours: '7:30 AM – 6:00 PM',
    emergency24x7: true,
    services: { opd: true, lab: true, pharmacy: true, emergency: true },
  },
]

export const doctors: Doctor[] = [
  { id: 'd1', name: 'Dr. Ananya Rao', hospitalId: 'h1', departmentId: 'gm', qualification: 'MBBS, MD', experienceYears: 12, languages: ['English', 'Tamil', 'Telugu'], status: 'available', avgConsultMin: 8, room: 'OPD-3', hours: '9:00 AM – 1:00 PM', fee: 300 },
  { id: 'd2', name: 'Dr. Vikram Menon', hospitalId: 'h1', departmentId: 'cardio', qualification: 'MBBS, DM Cardiology', experienceYears: 18, languages: ['English', 'Malayalam', 'Hindi'], status: 'available', avgConsultMin: 14, room: 'C-201', hours: '10:00 AM – 2:00 PM', fee: 800 },
  { id: 'd3', name: 'Dr. Priya Subramanian', hospitalId: 'h1', departmentId: 'peds', qualification: 'MBBS, DCH', experienceYears: 9, languages: ['English', 'Tamil'], status: 'on-break', avgConsultMin: 10, room: 'P-104', hours: '9:00 AM – 3:00 PM', fee: 400 },
  { id: 'd4', name: 'Dr. Rahul Sharma', hospitalId: 'h1', departmentId: 'ophth', qualification: 'MBBS, MS Ophth', experienceYears: 7, languages: ['English', 'Hindi'], status: 'available', avgConsultMin: 9, room: 'E-12', hours: '2:00 PM – 6:00 PM', fee: 500 },
  { id: 'd5', name: 'Dr. Kavya Reddy', hospitalId: 'h2', departmentId: 'derm', qualification: 'MBBS, MD Derm', experienceYears: 6, languages: ['English', 'Telugu', 'Kannada'], status: 'available', avgConsultMin: 11, room: 'S-2', hours: '11:00 AM – 7:00 PM', fee: 600 },
  { id: 'd6', name: 'Dr. Meera Iyer', hospitalId: 'h2', departmentId: 'gyn', qualification: 'MBBS, MS OBG', experienceYears: 15, languages: ['English', 'Tamil', 'Hindi'], status: 'in-surgery', avgConsultMin: 15, room: 'S-5', hours: '10:00 AM – 4:00 PM', fee: 700 },
  { id: 'd7', name: 'Dr. Arjun Nair', hospitalId: 'h3', departmentId: 'ortho', qualification: 'MBBS, MS Ortho', experienceYears: 11, languages: ['English', 'Kannada', 'Malayalam'], status: 'available', avgConsultMin: 12, room: 'B-7', hours: '9:00 AM – 5:00 PM', fee: 650 },
  { id: 'd8', name: 'Dr. Sameer Khan', hospitalId: 'h4', departmentId: 'gm', qualification: 'MBBS', experienceYears: 5, languages: ['English', 'Hindi', 'Telugu'], status: 'available', avgConsultMin: 6, room: 'OPD-1', hours: '8:00 AM – 2:00 PM', fee: 0 },
]

export const labs: Lab[] = [
  {
    id: 'l1', name: 'City General Diagnostics', hospitalId: 'h1', city: 'Chennai', hours: '7:00 AM – 9:00 PM', techniciansAvailable: 4, waitMin: 15,
    tests: [
      { id: 't1', name: 'Complete Blood Count (CBC)', price: 350, turnaroundHrs: 4, fasting: false },
      { id: 't2', name: 'Fasting Blood Sugar', price: 150, turnaroundHrs: 2, fasting: true },
      { id: 't3', name: 'Lipid Profile', price: 600, turnaroundHrs: 6, fasting: true },
      { id: 't4', name: 'Thyroid Profile (T3, T4, TSH)', price: 750, turnaroundHrs: 8, fasting: false },
      { id: 't5', name: 'ECG', price: 300, turnaroundHrs: 1, fasting: false },
    ],
  },
  {
    id: 'l2', name: 'Sunrise Path Labs', hospitalId: 'h2', city: 'Chennai', hours: '6:30 AM – 8:00 PM', techniciansAvailable: 2, waitMin: 28,
    tests: [
      { id: 't1', name: 'Complete Blood Count (CBC)', price: 300, turnaroundHrs: 5, fasting: false },
      { id: 't6', name: 'Vitamin D', price: 1200, turnaroundHrs: 24, fasting: false },
      { id: 't7', name: 'Urine Routine', price: 200, turnaroundHrs: 3, fasting: false },
    ],
  },
  {
    id: 'l3', name: 'Lakeview Imaging & Labs', hospitalId: 'h3', city: 'Bengaluru', hours: '24 hours', techniciansAvailable: 6, waitMin: 10,
    tests: [
      { id: 't8', name: 'Chest X-Ray', price: 500, turnaroundHrs: 2, fasting: false },
      { id: 't3', name: 'Lipid Profile', price: 650, turnaroundHrs: 6, fasting: true },
      { id: 't9', name: 'HbA1c', price: 550, turnaroundHrs: 6, fasting: false },
    ],
  },
]

export const pharmacies: Pharmacy[] = [
  {
    id: 'p1', name: 'City General Pharmacy', hospitalId: 'h1', city: 'Chennai', hours: '24 hours', open: true,
    medicines: [
      { id: 'm1', name: 'Paracetamol 500mg', generic: 'Paracetamol', price: 25, discountPct: 10, stock: 420, prescriptionRequired: false },
      { id: 'm2', name: 'Amoxicillin 500mg', generic: 'Amoxicillin', price: 120, discountPct: 5, stock: 60, prescriptionRequired: true },
      { id: 'm3', name: 'Atorvastatin 10mg', generic: 'Atorvastatin', price: 95, discountPct: 15, stock: 8, prescriptionRequired: true },
      { id: 'm4', name: 'ORS Sachet', generic: 'Oral rehydration salts', price: 20, discountPct: 0, stock: 300, prescriptionRequired: false },
      { id: 'm5', name: 'Cetirizine 10mg', generic: 'Cetirizine', price: 35, discountPct: 10, stock: 0, prescriptionRequired: false },
    ],
  },
  {
    id: 'p2', name: 'Sunrise MedPlus', hospitalId: 'h2', city: 'Chennai', hours: '8:00 AM – 11:00 PM', open: true,
    medicines: [
      { id: 'm1', name: 'Paracetamol 500mg', generic: 'Paracetamol', price: 22, discountPct: 12, stock: 250, prescriptionRequired: false },
      { id: 'm6', name: 'Metformin 500mg', generic: 'Metformin', price: 60, discountPct: 20, stock: 140, prescriptionRequired: true },
      { id: 'm5', name: 'Cetirizine 10mg', generic: 'Cetirizine', price: 32, discountPct: 5, stock: 90, prescriptionRequired: false },
    ],
  },
  {
    id: 'p3', name: 'District Jan Aushadhi Kendra', hospitalId: 'h4', city: 'Hyderabad', hours: '8:00 AM – 6:00 PM', open: false,
    medicines: [
      { id: 'm1', name: 'Paracetamol 500mg', generic: 'Paracetamol', price: 12, discountPct: 0, stock: 900, prescriptionRequired: false },
      { id: 'm7', name: 'Amlodipine 5mg', generic: 'Amlodipine', price: 18, discountPct: 0, stock: 200, prescriptionRequired: true },
    ],
  },
]

const now = Date.now()
const min = 60_000

export const labOrders: LabOrder[] = [
  { id: 'lo1', token: 'LB-101', patientName: 'Suresh K', labId: 'l1', testIds: ['t1', 't2'], status: 'processing', createdAt: now - 70 * min },
  { id: 'lo2', token: 'LB-102', patientName: 'Fatima B', labId: 'l1', testIds: ['t3'], status: 'sample-collected', createdAt: now - 40 * min },
  { id: 'lo3', token: 'LB-103', patientName: 'Ravi T', labId: 'l1', testIds: ['t5'], status: 'booked', createdAt: now - 15 * min },
  { id: 'lo4', token: 'LB-104', patientName: 'Lakshmi P', labId: 'l1', testIds: ['t4'], status: 'booked', createdAt: now - 5 * min },
]

export const appointments: Appointment[] = [
  { id: 'a1', doctorId: 'd1', hospitalId: 'h1', date: 'Today', time: '11:20 AM', status: 'upcoming', tokenNumber: 'GM-018' },
  { id: 'a2', doctorId: 'd4', hospitalId: 'h1', date: 'Oct 14', time: '3:00 PM', status: 'upcoming' },
  { id: 'a3', doctorId: 'd2', hospitalId: 'h1', date: 'Sep 22', time: '10:40 AM', status: 'completed' },
  { id: 'a4', doctorId: 'd5', hospitalId: 'h2', date: 'Sep 03', time: '5:15 PM', status: 'no-show' },
]

export const notifications: Notification[] = [
  { id: 'n1', title: 'Your turn is approaching', body: '3 patients ahead of you for Dr. Ananya Rao, Room OPD-3.', type: 'queue', createdAt: now - 4 * min, read: false },
  { id: 'n2', title: 'Lab report ready', body: 'Your CBC report from City General Diagnostics is ready.', type: 'lab', createdAt: now - 90 * min, read: false },
  { id: 'n3', title: 'Earlier slot available', body: 'A 10:40 AM slot opened up with Dr. Rahul Sharma on Oct 14.', type: 'appointment', createdAt: now - 3 * 60 * min, read: true },
  { id: 'n4', title: 'Prescription verified', body: 'Your prescription is verified at City General Pharmacy. Counter 2.', type: 'pharmacy', createdAt: now - 26 * 60 * min, read: true },
]

export const auditLogs: AuditLog[] = [
  { id: 'al1', actor: 'Nisha (Front desk)', role: 'staff', action: 'Escalated token to emergency', target: 'GM-021', at: now - 6 * min },
  { id: 'al2', actor: 'Dr. Ananya Rao', role: 'doctor', action: 'Changed status to available', target: 'OPD-3', at: now - 18 * min },
  { id: 'al3', actor: 'Kiran (Pharmacy)', role: 'pharmacy', action: 'Updated stock', target: 'Atorvastatin 10mg', at: now - 42 * min },
  { id: 'al4', actor: 'Admin', role: 'admin', action: 'Changed SLA threshold to 45 min', target: 'City General Hospital', at: now - 2 * 60 * min },
  { id: 'al5', actor: 'Ramesh (Lab)', role: 'lab', action: 'Marked sample collected', target: 'LB-102', at: now - 38 * min },
]

/** Historical demand index per hour (8 AM – 8 PM), used by ETA + slot recommendation. */
export const hourlyDemand: Record<number, number> = {
  8: 0.7, 9: 1.15, 10: 1.35, 11: 1.3, 12: 1.05, 13: 0.8, 14: 0.85, 15: 0.95, 16: 1.05, 17: 1.1, 18: 0.9, 19: 0.7, 20: 0.55,
}

export const analytics = {
  hourlyVolume: [8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19].map((h) => ({
    hour: `${h > 12 ? h - 12 : h}${h >= 12 ? 'p' : 'a'}`,
    patients: Math.round(40 * (hourlyDemand[h] ?? 0.8)),
    avgWait: Math.round(22 * (hourlyDemand[h] ?? 0.8)),
  })),
  departmentDemand: [
    { name: 'General Med', value: 412 },
    { name: 'Pediatrics', value: 208 },
    { name: 'Orthopedics', value: 164 },
    { name: 'Cardiology', value: 131 },
    { name: 'Ophthalmology', value: 97 },
    { name: 'ENT', value: 76 },
  ],
  doctorUtilization: [
    { name: 'Dr. Rao', utilization: 92, consults: 38 },
    { name: 'Dr. Menon', utilization: 78, consults: 17 },
    { name: 'Dr. Subramanian', utilization: 64, consults: 22 },
    { name: 'Dr. Sharma', utilization: 71, consults: 25 },
    { name: 'Dr. Nair', utilization: 85, consults: 29 },
  ],
  appointments: [
    { day: 'Mon', booked: 180, completed: 158, cancelled: 12, noShow: 10 },
    { day: 'Tue', booked: 164, completed: 149, cancelled: 8, noShow: 7 },
    { day: 'Wed', booked: 172, completed: 150, cancelled: 14, noShow: 8 },
    { day: 'Thu', booked: 190, completed: 171, cancelled: 9, noShow: 10 },
    { day: 'Fri', booked: 205, completed: 183, cancelled: 11, noShow: 11 },
    { day: 'Sat', booked: 142, completed: 128, cancelled: 6, noShow: 8 },
  ],
  labs: [
    { day: 'Mon', tests: 96, avgQueue: 18 },
    { day: 'Tue', tests: 88, avgQueue: 15 },
    { day: 'Wed', tests: 102, avgQueue: 21 },
    { day: 'Thu', tests: 110, avgQueue: 24 },
    { day: 'Fri', tests: 121, avgQueue: 27 },
    { day: 'Sat', tests: 74, avgQueue: 12 },
  ],
}

export const departmentName = (id: string) => departments.find((d) => d.id === id)?.name ?? id
export const hospitalName = (id: string | null) => hospitals.find((h) => h.id === id)?.name ?? 'Independent'
export const doctorById = (id: string) => doctors.find((d) => d.id === id)
