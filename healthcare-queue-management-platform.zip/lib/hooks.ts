'use client'

import useSWR, { mutate } from 'swr'
import { ai, appointments, auth, directory, labs, misc, queue } from './api'

const LIVE = { refreshInterval: 4000, revalidateOnFocus: true }

export const useMe = () => useSWR('me', auth.me)
export const useHospitals = () => useSWR('hospitals', directory.hospitals)
export const useDepartments = () => useSWR('departments', directory.departments)
export const useDoctors = () => useSWR('doctors', directory.doctors, LIVE)
export const useLabs = () => useSWR('labs', directory.labs)
export const usePharmacies = () => useSWR('pharmacies', directory.pharmacies)

export const useQueue = (doctorId: string | null) =>
  useSWR(doctorId ? ['queue', doctorId] : null, () => queue.get(doctorId!), LIVE)
export const useAllQueues = () => useSWR('queues', queue.all, LIVE)
export const useToken = (tokenId: string | null) =>
  useSWR(tokenId ? ['token', tokenId] : null, () => queue.token(tokenId!), LIVE)
export const useMyTokens = () => useSWR('my-tokens', queue.mine, LIVE)
export const useEta = (tokenId: string | null) =>
  useSWR(tokenId ? ['eta', tokenId] : null, () => ai.eta(tokenId!), LIVE)
export const useAlerts = () => useSWR('alerts', queue.alerts, { refreshInterval: 8000 })
export const useSlots = (doctorId: string | null, day: number) =>
  useSWR(doctorId ? ['slots', doctorId, day] : null, () => ai.slots(doctorId!, day))

export const useAppointments = () => useSWR('appointments', appointments.mine)
export const useLabOrders = () => useSWR('lab-orders', labs.orders, LIVE)
export const useNotifications = () => useSWR('notifications', misc.notifications)
export const useAuditLogs = () => useSWR('audit-logs', misc.auditLogs)
export const useAnalytics = () => useSWR('analytics', misc.analytics)

/** Revalidate every queue-related cache after a queue event. */
export const refreshQueues = () =>
  mutate(
    (key) => {
      const k = Array.isArray(key) ? key[0] : key
      return ['queue', 'queues', 'token', 'my-tokens', 'eta', 'alerts', 'doctors'].includes(k as string)
    },
    undefined,
    { revalidate: true },
  )
