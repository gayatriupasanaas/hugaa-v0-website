import type { Metadata } from 'next'
import { AuthPanel } from '@/components/auth/auth-panel'

export const metadata: Metadata = { title: 'Sign in — HUGA' }

export default function LoginPage() {
  return (
    <main className="mx-auto flex min-h-[calc(100dvh-4rem)] max-w-7xl items-center justify-center px-4 py-10">
      <AuthPanel />
    </main>
  )
}
