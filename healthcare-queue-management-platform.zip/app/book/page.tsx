import type { Metadata } from 'next'
import { Suspense } from 'react'
import { PageShell } from '@/components/page-shell'
import { BookingFlow } from '@/components/booking/booking-flow'
import { Skeleton } from '@/components/ui-kit'

export const metadata: Metadata = { title: 'Book an appointment — HUGA' }

export default function BookPage() {
  return (
    <PageShell>
      <Suspense fallback={<Skeleton className="h-96" />}>
        <BookingFlow />
      </Suspense>
    </PageShell>
  )
}
