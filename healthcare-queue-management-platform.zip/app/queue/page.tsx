import type { Metadata } from 'next'
import { Suspense } from 'react'
import { PageShell } from '@/components/page-shell'
import { QueueLookup } from '@/components/queue/queue-lookup'
import { Skeleton } from '@/components/ui-kit'

export const metadata: Metadata = { title: 'Live queue — HUGA' }

export default function QueuePage() {
  return (
    <PageShell>
      <Suspense fallback={<Skeleton className="h-96" />}>
        <QueueLookup />
      </Suspense>
    </PageShell>
  )
}
