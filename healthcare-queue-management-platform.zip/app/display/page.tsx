import type { Metadata } from 'next'
import { DisplayBoard } from '@/components/queue/display-board'

export const metadata: Metadata = { title: 'Waiting-area display — HUGA' }

export default function DisplayPage() {
  return <DisplayBoard />
}
