import type { Metadata } from 'next'
import { Suspense } from 'react'
import { PageShell } from '@/components/page-shell'
import { CheckInKiosk } from '@/components/queue/check-in-kiosk'
import { Skeleton } from '@/components/ui-kit'

export const metadata: Metadata = { title: 'Walk-in check-in — HUGA' }

export default function CheckInPage() {
  return (
    <PageShell>
      <Suspense fallback={<Skeleton className="h-96" />}>
        <CheckInKiosk />
      </Suspense>
    </PageShell>
  )
}
