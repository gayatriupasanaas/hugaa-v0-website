import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Geist_Mono } from 'next/font/google'
import { PreferencesProvider } from '@/lib/i18n'
import { SiteHeader } from '@/components/site-header'
import { AssistantWidget } from '@/components/assistant-widget'
import { DemoBanner } from '@/components/demo-banner'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist-sans' })
const geistMono = Geist_Mono({ subsets: ['latin'], variable: '--font-geist-mono' })

export const metadata: Metadata = {
  title: 'HUGA — Smart Hospital Queues & AI Waiting Times',
  description:
    'Digital tokens, live queue tracking, AI waiting-time prediction and real-time updates for hospitals, clinics, labs and pharmacies.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  themeColor: '#0f7c80',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${geist.variable} ${geistMono.variable} bg-background`}>
      <body className="min-h-dvh antialiased">
        <PreferencesProvider>
          <DemoBanner />
          <SiteHeader />
          <div id="main">{children}</div>
          <AssistantWidget />
        </PreferencesProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
