import type { Metadata } from 'next'
import { PageShell } from '@/components/page-shell'
import { LabBooking } from '@/components/services/lab-booking'

export const metadata: Metadata = { title: 'Diagnostic labs — HUGA' }

export default function LabsPage() {
  return (
    <PageShell>
      <LabBooking />
    </PageShell>
  )
}
