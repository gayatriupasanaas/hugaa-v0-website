import type { Metadata } from 'next'
import { PageShell } from '@/components/page-shell'
import { PharmacyFinder } from '@/components/services/pharmacy-finder'

export const metadata: Metadata = { title: 'Pharmacies — HUGA' }

export default function PharmacyPage() {
  return (
    <PageShell>
      <PharmacyFinder />
    </PageShell>
  )
}
