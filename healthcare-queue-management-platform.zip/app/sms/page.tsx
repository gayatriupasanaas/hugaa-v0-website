import type { Metadata } from 'next'
import { PageShell } from '@/components/page-shell'
import { SmsSimulator } from '@/components/queue/sms-simulator'
import { PageHeader } from '@/components/ui-kit'

export const metadata: Metadata = { title: 'SMS access — HUGA' }

export default function SmsPage() {
  return (
    <PageShell>
      <PageHeader
        eyebrow="Offline access"
        title="Check your queue by SMS"
        description="Patients without smartphones or internet can text STATUS followed by their token number. Try the simulator below."
      />
      <SmsSimulator />
    </PageShell>
  )
}
