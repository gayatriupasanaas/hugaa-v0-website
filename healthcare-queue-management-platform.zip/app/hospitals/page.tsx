import type { Metadata } from 'next'
import { PageShell } from '@/components/page-shell'
import { HospitalDirectory } from '@/components/directory/hospital-directory'

export const metadata: Metadata = { title: 'Hospitals & doctors — HUGA' }

export default function HospitalsPage() {
  return (
    <PageShell>
      <HospitalDirectory />
    </PageShell>
  )
}
