import { LandingHero } from '@/components/landing/hero'
import { LandingFeatures } from '@/components/landing/features'
import { LandingRoles } from '@/components/landing/roles'
import { SiteFooter } from '@/components/site-footer'

export default function HomePage() {
  return (
    <main>
      <LandingHero />
      <LandingFeatures />
      <LandingRoles />
      <SiteFooter />
    </main>
  )
}
